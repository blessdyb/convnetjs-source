export const ICONS = {
  LEFT: "chevronLeft",
  RIGHT: "chevronRight",
};

export const WIDTHS = {
  ARROW: 42,
  ARROW_OFFSET: 16,
};
