import FlyoutMenu from "./Component";
import withActiveLinkDetection from "./withActiveLinkDetection";

export default withActiveLinkDetection(FlyoutMenu);
