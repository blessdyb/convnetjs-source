define(
  "@widget/LAYOUT/c/bs-overlayTypes-e1dbe765.js",
  ["exports"],
  function (e) {
    "use strict";
    const {
      headerTreatments: { FILL: n, FIT: t, INSET: o, BLUR: a, LEGACY_BLUR: c },
    } = (global.Core || guac["@wsb/guac-widget-core"]).constants;
    (e.A = "accent"),
      (e.B = a),
      (e.C = "category"),
      (e.F = n),
      (e.I = o),
      (e.L = c),
      (e.N = "neutral"),
      (e.P = "primary"),
      (e.a = "none"),
      (e.b = t),
      (e.c = "light_dark");
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-overlayTypes-e1dbe765.js.map
