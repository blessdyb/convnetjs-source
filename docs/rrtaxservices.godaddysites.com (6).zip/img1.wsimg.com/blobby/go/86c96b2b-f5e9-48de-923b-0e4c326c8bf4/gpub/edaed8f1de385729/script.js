window.cxs && window.cxs.setOptions({ prefix: "c2-" });
window.wsb = window.wsb || {};
window.wsb["Theme27"] =
  window.wsb["Theme27"] ||
  window
    .radpack("@widget/LAYOUT/bs-layout27-Theme-publish-Theme")
    .then(function (t) {
      return new t.default();
    });
window.wsb["context-bs-1"] = JSON.parse(
  '{"env":"production","renderMode":"PUBLISH","fonts":["playfair-display","cabin","raleway"],"colors":["#54e8de"],"locale":"en-US","language":"en","resellerId":1,"internalLinks":{"4077c4d1-5de2-460f-b9ce-68c49844e2f3":{"pageId":"c30324ce-df92-47bf-ab46-2985fef559c2","routePath":"/contact-us"},"e1cb7e3d-1f13-4daf-bd40-0a27b8b5d3df":{"pageId":"7556607b-a69b-4bf6-b554-18b0087312b7","routePath":"/"},"8d39fefb-81a4-4203-9ea2-e88cf47a6b3f":{"pageId":"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8","widgetId":null,"routePath":"/about-us"},"0d6a5392-fd35-465d-9210-c9fe2a0ea768":{"pageId":"57db8abd-7373-4fed-86d5-80b36c269ad6","widgetId":null,"routePath":"/tax-preparation"},"474ac411-1182-4d85-a3c6-fe02d91e7512":{"pageId":"7109a5f3-4a13-4c2f-b952-ec2cde3270a4","widgetId":null,"routePath":"/audit-representation"}},"isInternalPage":true,"navigationMap":{"7556607b-a69b-4bf6-b554-18b0087312b7":{"isFlyoutMenu":false,"active":false,"pageId":"7556607b-a69b-4bf6-b554-18b0087312b7","name":"Home","href":"/","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6":{"isFlyoutMenu":true,"active":false,"pageId":"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6","name":"Tax Services","href":"/tax-services-1","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"3d220b3f-811b-4def-8141-f8494df1dde0":{"isFlyoutMenu":false,"active":false,"pageId":"3d220b3f-811b-4def-8141-f8494df1dde0","name":"Tax Planning","href":"/tax-planning","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"9d7adc46-941a-470f-9977-4fee75036d43":{"isFlyoutMenu":false,"active":false,"pageId":"9d7adc46-941a-470f-9977-4fee75036d43","name":"404","href":"/404","target":"","visible":false,"requiresAuth":false,"tags":["404"],"rel":"","type":"page","showInFooter":false},"c30324ce-df92-47bf-ab46-2985fef559c2":{"isFlyoutMenu":false,"active":false,"pageId":"c30324ce-df92-47bf-ab46-2985fef559c2","name":"Contact Us","href":"/contact-us","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"57db8abd-7373-4fed-86d5-80b36c269ad6":{"isFlyoutMenu":false,"active":false,"pageId":"57db8abd-7373-4fed-86d5-80b36c269ad6","name":"Tax Preparation","href":"/tax-preparation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"1da45406-53a6-4585-bdde-b2e83157a9fd":{"isFlyoutMenu":false,"active":true,"pageId":"1da45406-53a6-4585-bdde-b2e83157a9fd","name":"Testimonials","href":"/testimonials","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8":{"isFlyoutMenu":false,"active":false,"pageId":"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8","name":"About Us","href":"/about-us","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"a17917ef-697e-4982-a659-6400f9362c8c":{"isFlyoutMenu":false,"active":false,"pageId":"a17917ef-697e-4982-a659-6400f9362c8c","name":"Tax Tips","href":"/tax-tips","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"7109a5f3-4a13-4c2f-b952-ec2cde3270a4":{"isFlyoutMenu":false,"active":false,"pageId":"7109a5f3-4a13-4c2f-b952-ec2cde3270a4","name":"Audit Representation","href":"/audit-representation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false}},"dials":{"colors":[{"id":"#54e8de","meta":{"primary":"rgb(84, 232, 222)","accent":"rgb(17, 17, 17)","neutral":"rgb(255, 255, 255)"}}],"fonts":{"primary":{"id":"playfair-display","description":"Distinctive fonts that presents a 21st century take on a vintage, professional feel.","tags":["serif","classic","conservative"],"meta":{"order":30,"primary":{"id":"playfair-display","name":"Playfair Display","url":"//fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap","family":"\'Playfair Display\', Georgia, serif","size":16,"weight":400,"weights":[400,700,900]},"alternate":{"id":"open-sans","name":"Open Sans","url":"//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800&display=swap","family":"\'Open Sans\', arial, sans-serif","size":16,"weight":400,"weights":[300,400,700,800],"styles":{"letterSpacing":"normal","textTransform":"none"}}},"overridesAlternate":[{"locales":["ja-JP"],"meta":{"alternate":{"family":"Open Sans, MS Mincho, \'\uFF2D\uFF33 \uFF30\u660E\u671D\', serif"}}},{"locales":["ko-KR"],"meta":{"alternate":{"family":"Open Sans, \'\uBC14\uD0D5\', Batang, \'\uBC14\uD0D5\uCCB4\', BatangChe, serif"}}},{"locales":["th-TH"],"meta":{"alternate":{"family":"Open Sans, Krungthep, Thonburi, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"alternate":{"family":"Open Sans, \'\u534E\u6587\u9ED1\u4F53\', STHeiti, Heiti SC, sans-serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"alternate":{"family":"Open Sans, Hiragino Sans GB, sans-serif"}}}],"overridesPrimary":[{"locales":["vi-VN","ta-IN","mr-IN","hi-IN"],"meta":{"primary":{"family":"Georgia, serif"}}},{"locales":["ja-JP"],"meta":{"primary":{"family":"Playfair Display, Hiragino Mincho Pro, \'\u30D2\u30E9\u30AE\u30CE\u660E\u671DPro\', Hiragino Mincho ProN, \'\u30D2\u30E9\u30AE\u30CE\u660E\u671DProN\', serif"}}},{"locales":["ko-KR"],"meta":{"primary":{"family":"Playfair Display, \'\uC560\uD50C\uACE0\uB515\', Apple SD Gothic Neo, \'\uC560\uD50C\uACE0\uB515\', AppleGothic, sans-serif"}}},{"locales":["th-TH"],"meta":{"primary":{"family":"Playfair Display, Thonburi, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"primary":{"family":"Playfair Display, Hiragino Sans GB, sans-serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"primary":{"family":"Playfair Display, \'\u5137\u9ED1 Pro\', LiHei Pro, sans-serif"}}}]},"alternate":{"id":"cabin","description":"Clean and modern fonts that extremely versatile.","tags":["sans-serif","modern","clean"],"meta":{"order":1,"alternate":{"id":"cabin","name":"Cabin","url":"//fonts.googleapis.com/css?family=Cabin:400,400i,600,700&display=swap","family":"\'Cabin\', Georgia, serif","size":16,"weight":400,"weights":[400,600,700],"styles":{"letterSpacing":"normal","textTransform":"none"}}},"overridesAlternate":[{"locales":["ja-JP"],"meta":{"alternate":{"family":"Cabin, Hiragino Kaku Gothic Pro, \'\u30D2\u30E9\u30AE\u30CE\u89D2\u30B4 Pro\', Hiragino Kaku Gothic ProN, \'\u30D2\u30E9\u30AE\u30CE\u89D2\u30B4 ProN\', sans-serif"}}},{"locales":["ko-KR"],"meta":{"alternate":{"family":"Cabin, \'\uB3CB\uC6C0\', Dotum, \'\uB3CB\uC6C0\uCCB4\', DotumChe, sans-serif"}}},{"locales":["th-TH"],"meta":{"alternate":{"family":"Cabin, JasmineUPC, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"alternate":{"family":"Cabin, \'\u534E\u6587\u5B8B\u4F53\', STSong, serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"alternate":{"family":"Cabin, \'\u5137\u5B8B Pro\', LiSong Pro, serif"}}}]},"logo":{"id":"raleway","description":"","tags":[],"meta":{"order":32,"logo":{"id":"raleway","name":"Raleway","url":"//fonts.googleapis.com/css?family=Raleway:700,400&display=swap","family":"\'Raleway\', arial, Sans-Serif","size":14,"weight":400,"weights":[400,700],"styles":{"letterSpacing":"4px","textTransform":"uppercase","fontWeight":400,"fontSize":"xlarge"}}}}}},"theme":"Theme27","paintJob":"LIGHT"}'
);
Core.utils.deferBootstrap(
  {
    elId: "bs-1",
    componentName: "@widget/LAYOUT/bs-FlyoutMenu-Component",
    props: JSON.parse(
      '{"toggleId":"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6-nav-25103-toggleId","label":"Tax Services","navBarId":"nav-25100","parentId":"nav-25103","widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","section":"alt","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","widgetType":"HEADER","widgetPreset":"header9","group":"Nav","groupType":"Default","section":"alt","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-1",
    radpack: "@widget/LAYOUT/bs-FlyoutMenu-Component",
  },
  false
);
Core.utils.deferBootstrap(
  {
    elId: "bs-2",
    componentName: "@widget/LAYOUT/bs-LinkAwareComponent",
    props: JSON.parse(
      '{"toggleId":"more-25104","label":"More","dataAid":"NAV_MORE","navBarId":"nav-25100","widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","section":"alt","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","widgetType":"HEADER","widgetPreset":"header9","group":"Nav","groupType":"Default","section":"alt","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-1",
    radpack: "@widget/LAYOUT/bs-LinkAwareComponent",
  },
  false
);
window.wsb["CalculateNavSpacing"] = function (e) {
  let {
    containerId: a,
    navId: n,
    logoImageId: l,
    inlineUtilitiesMenu: i,
    forceBreakpoint: o,
  } = e;
  let r, c, s, g, p, d, u;
  const y = document.getElementById(n);
  function m() {
    if (c || !y || !R(y)) return;
    (s = Array.from(y.children)),
      s.forEach(w),
      i && ((g = s.pop()), f(g)),
      (p = s.pop());
    const e = p.querySelector("ul");
    (d = e ? Array.from(e.children) : []),
      (y.style.whiteSpace = "normal"),
      (u = R(y.parentElement, "floor")),
      (y.style.whiteSpace = "nowrap"),
      window.requestAnimationFrame(b);
  }
  function b() {
    const e = s.map((e) => R(e));
    const t = g ? R(g) : 0,
      a = u - t;
    if (E(e) > a) {
      const t = R(p);
      for (let n = E(e); n + t > a; n -= e.pop());
      const n = e.length;
      h(s, 0, n, f),
        h(d, 0, n, I),
        h(s, n, s.length, I),
        h(d, n, s.length, f),
        f(p);
    } else s.forEach(f), I(p);
    window.dispatchEvent(new Event("NavItemsResized"));
  }
  function v() {
    (window.innerWidth < 1024 && o && o !== t.Q) ||
      (window.clearTimeout(r), (r = window.setTimeout(m, 50)));
  }
  function h(e, t, a, n) {
    e = e.slice(t, a).map(n).concat(e.slice(a));
  }
  function w(e) {
    (e.style.visibility = "hidden"),
      (e.style.display = ""),
      e.classList.remove("visible");
  }
  function I(e) {
    (e.style.display = "none"), e.classList.remove("visible");
  }
  function f(e) {
    (e.style.visibility = "visible"),
      (e.style.display = ""),
      e.classList.add("visible");
  }
  function E(e) {
    return e.reduce((e, t) => e + t, 0);
  }
  function R(e) {
    let t =
      arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ceil";
    return "ceil" === t
      ? Math.ceil(e.getBoundingClientRect().width)
      : Math.floor(e.getBoundingClientRect().width);
  }
  if ((v(), window.ResizeObserver)) {
    const e = new window.ResizeObserver(v);
    return (
      [document.getElementById(a), document.getElementById(l)].forEach(
        (t) => t && e.observe(t)
      ),
      () => {
        (c = !0), e.disconnect();
      }
    );
  }
  return (
    window.addEventListener("resize", v, { passive: !0 }),
    () => {
      (c = !0), window.removeEventListener("resize", v, { passive: !0 });
    }
  );
};
window.wsb["CalculateNavSpacing"](
  JSON.parse('{"navId":"nav-25103","containerId":"nav-25100"}')
);
Core.utils.deferBootstrap(
  {
    elId: "bs-3",
    componentName: "@widget/LAYOUT/bs-Hamburger-Component",
    props: JSON.parse(
      '{"toggleId":"n-25099-navId-mobile","uniqueId":"n-25099","style":{"color":"highContrast",":hover":{"color":"highlight"},"@md":{"display":"none"}},"widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","section":"alt","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","widgetType":"HEADER","widgetPreset":"header9","group":"Section","groupType":"Default","section":"alt","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-1",
    radpack: "@widget/LAYOUT/bs-Hamburger-Component",
  },
  false
);
Core.utils.deferBootstrap(
  {
    elId: "bs-4",
    componentName: "@widget/LAYOUT/bs-MobileFlyoutMenu-Component",
    props: JSON.parse(
      '{"item":{"isFlyoutMenu":true,"active":false,"pageId":"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6","name":"Tax Services","href":"/tax-services-1","target":"","visible":true,"navigation":[{"isFlyoutMenu":false,"active":false,"pageId":"3d220b3f-811b-4def-8141-f8494df1dde0","name":"Tax Planning","href":"/tax-planning","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},{"isFlyoutMenu":false,"active":false,"pageId":"57db8abd-7373-4fed-86d5-80b36c269ad6","name":"Tax Preparation","href":"/tax-preparation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},{"isFlyoutMenu":false,"active":false,"pageId":"7109a5f3-4a13-4c2f-b952-ec2cde3270a4","name":"Audit Representation","href":"/audit-representation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false}],"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"styles":{"mobileOnly":{"@xs":{"display":"block"},"@md":{"display":"none"}},"overlay":{"position":"fixed","overflow":"hidden","display":"flex","flexDirection":"column"},"innerContainer":{"overflowY":"auto","overflowX":"hidden","width":"100%","overscrollBehavior":"none"},"topContainer":{"paddingHorizontal":"medium"},"membershipHeader":{"paddingBottom":"large"},"close":{"position":"absolute","top":15,"right":15,"fontSize":"xlarge"},"list":{"textAlign":"left","paddingVertical":"0","paddingHorizontal":"0","wordWrap":"break-word","overflowWrap":"break-word"},"subList":{"paddingHorizontal":"0","paddingTop":"0","paddingBottom":"small"},"subListItem":{"display":"block","marginBottom":"0","borderBottomWidth":"0",":last-child":{"paddingBottom":"medium"}},"socialContainer":{"display":"flex","justifyContent":"flex-start","alignItems":"center","marginBottom":"large","flexDirection":"column","> :not(:first-child)":{"marginTop":"small"}},"searchFormContainer":{"position":"relative","height":"auto"},"translateContainer":{"@md":{"display":"none"}}},"domainName":"rrtaxservices.godaddysites.com","pageRoute":"/testimonials","widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","section":"default","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"widgetId":"e426ab3d-aa3d-4263-8490-c868a320d10d","widgetType":"HEADER","widgetPreset":"header9","group":"NavigationDrawer","groupType":"Default","section":"default","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-1",
    radpack: "@widget/LAYOUT/bs-MobileFlyoutMenu-Component",
  },
  false
);
window.wsb["context-bs-5"] = JSON.parse(
  '{"env":"production","renderMode":"PUBLISH","fonts":["playfair-display","cabin","raleway"],"colors":["#54e8de"],"fontScale":"medium","locale":"en-US","language":"en","resellerId":1,"internalLinks":{"4077c4d1-5de2-460f-b9ce-68c49844e2f3":{"pageId":"c30324ce-df92-47bf-ab46-2985fef559c2","routePath":"/contact-us"},"e1cb7e3d-1f13-4daf-bd40-0a27b8b5d3df":{"pageId":"7556607b-a69b-4bf6-b554-18b0087312b7","routePath":"/"},"8d39fefb-81a4-4203-9ea2-e88cf47a6b3f":{"pageId":"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8","widgetId":null,"routePath":"/about-us"},"0d6a5392-fd35-465d-9210-c9fe2a0ea768":{"pageId":"57db8abd-7373-4fed-86d5-80b36c269ad6","widgetId":null,"routePath":"/tax-preparation"},"474ac411-1182-4d85-a3c6-fe02d91e7512":{"pageId":"7109a5f3-4a13-4c2f-b952-ec2cde3270a4","widgetId":null,"routePath":"/audit-representation"}},"isInternalPage":true,"navigationMap":{"7556607b-a69b-4bf6-b554-18b0087312b7":{"isFlyoutMenu":false,"active":false,"pageId":"7556607b-a69b-4bf6-b554-18b0087312b7","name":"Home","href":"/","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6":{"isFlyoutMenu":true,"active":false,"pageId":"623dbeb6-09b7-4471-9dfa-660dd5ecc7d6","name":"Tax Services","href":"/tax-services-1","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"3d220b3f-811b-4def-8141-f8494df1dde0":{"isFlyoutMenu":false,"active":false,"pageId":"3d220b3f-811b-4def-8141-f8494df1dde0","name":"Tax Planning","href":"/tax-planning","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"9d7adc46-941a-470f-9977-4fee75036d43":{"isFlyoutMenu":false,"active":false,"pageId":"9d7adc46-941a-470f-9977-4fee75036d43","name":"404","href":"/404","target":"","visible":false,"requiresAuth":false,"tags":["404"],"rel":"","type":"page","showInFooter":false},"c30324ce-df92-47bf-ab46-2985fef559c2":{"isFlyoutMenu":false,"active":false,"pageId":"c30324ce-df92-47bf-ab46-2985fef559c2","name":"Contact Us","href":"/contact-us","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"57db8abd-7373-4fed-86d5-80b36c269ad6":{"isFlyoutMenu":false,"active":false,"pageId":"57db8abd-7373-4fed-86d5-80b36c269ad6","name":"Tax Preparation","href":"/tax-preparation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"1da45406-53a6-4585-bdde-b2e83157a9fd":{"isFlyoutMenu":false,"active":true,"pageId":"1da45406-53a6-4585-bdde-b2e83157a9fd","name":"Testimonials","href":"/testimonials","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8":{"isFlyoutMenu":false,"active":false,"pageId":"9129fb4a-2891-4a1a-a207-73aa5ec9e7b8","name":"About Us","href":"/about-us","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"a17917ef-697e-4982-a659-6400f9362c8c":{"isFlyoutMenu":false,"active":false,"pageId":"a17917ef-697e-4982-a659-6400f9362c8c","name":"Tax Tips","href":"/tax-tips","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false},"7109a5f3-4a13-4c2f-b952-ec2cde3270a4":{"isFlyoutMenu":false,"active":false,"pageId":"7109a5f3-4a13-4c2f-b952-ec2cde3270a4","name":"Audit Representation","href":"/audit-representation","target":"","visible":true,"requiresAuth":false,"tags":[],"rel":"","type":"page","showInFooter":false}},"dials":{"colors":[{"id":"#54e8de","meta":{"primary":"rgb(84, 232, 222)","accent":"rgb(17, 17, 17)","neutral":"rgb(255, 255, 255)"}}],"fonts":{"primary":{"id":"playfair-display","description":"Distinctive fonts that presents a 21st century take on a vintage, professional feel.","tags":["serif","classic","conservative"],"meta":{"order":30,"primary":{"id":"playfair-display","name":"Playfair Display","url":"//fonts.googleapis.com/css?family=Playfair+Display:400,700,900&display=swap","family":"\'Playfair Display\', Georgia, serif","size":16,"weight":400,"weights":[400,700,900]},"alternate":{"id":"open-sans","name":"Open Sans","url":"//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800&display=swap","family":"\'Open Sans\', arial, sans-serif","size":16,"weight":400,"weights":[300,400,700,800],"styles":{"letterSpacing":"normal","textTransform":"none"}}},"overridesAlternate":[{"locales":["ja-JP"],"meta":{"alternate":{"family":"Open Sans, MS Mincho, \'\uFF2D\uFF33 \uFF30\u660E\u671D\', serif"}}},{"locales":["ko-KR"],"meta":{"alternate":{"family":"Open Sans, \'\uBC14\uD0D5\', Batang, \'\uBC14\uD0D5\uCCB4\', BatangChe, serif"}}},{"locales":["th-TH"],"meta":{"alternate":{"family":"Open Sans, Krungthep, Thonburi, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"alternate":{"family":"Open Sans, \'\u534E\u6587\u9ED1\u4F53\', STHeiti, Heiti SC, sans-serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"alternate":{"family":"Open Sans, Hiragino Sans GB, sans-serif"}}}],"overridesPrimary":[{"locales":["vi-VN","ta-IN","mr-IN","hi-IN"],"meta":{"primary":{"family":"Georgia, serif"}}},{"locales":["ja-JP"],"meta":{"primary":{"family":"Playfair Display, Hiragino Mincho Pro, \'\u30D2\u30E9\u30AE\u30CE\u660E\u671DPro\', Hiragino Mincho ProN, \'\u30D2\u30E9\u30AE\u30CE\u660E\u671DProN\', serif"}}},{"locales":["ko-KR"],"meta":{"primary":{"family":"Playfair Display, \'\uC560\uD50C\uACE0\uB515\', Apple SD Gothic Neo, \'\uC560\uD50C\uACE0\uB515\', AppleGothic, sans-serif"}}},{"locales":["th-TH"],"meta":{"primary":{"family":"Playfair Display, Thonburi, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"primary":{"family":"Playfair Display, Hiragino Sans GB, sans-serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"primary":{"family":"Playfair Display, \'\u5137\u9ED1 Pro\', LiHei Pro, sans-serif"}}}]},"alternate":{"id":"cabin","description":"Clean and modern fonts that extremely versatile.","tags":["sans-serif","modern","clean"],"meta":{"order":1,"alternate":{"id":"cabin","name":"Cabin","url":"//fonts.googleapis.com/css?family=Cabin:400,400i,600,700&display=swap","family":"\'Cabin\', Georgia, serif","size":16,"weight":400,"weights":[400,600,700],"styles":{"letterSpacing":"normal","textTransform":"none"}}},"overridesAlternate":[{"locales":["ja-JP"],"meta":{"alternate":{"family":"Cabin, Hiragino Kaku Gothic Pro, \'\u30D2\u30E9\u30AE\u30CE\u89D2\u30B4 Pro\', Hiragino Kaku Gothic ProN, \'\u30D2\u30E9\u30AE\u30CE\u89D2\u30B4 ProN\', sans-serif"}}},{"locales":["ko-KR"],"meta":{"alternate":{"family":"Cabin, \'\uB3CB\uC6C0\', Dotum, \'\uB3CB\uC6C0\uCCB4\', DotumChe, sans-serif"}}},{"locales":["th-TH"],"meta":{"alternate":{"family":"Cabin, JasmineUPC, Tahoma, sans-serif"}}},{"locales":["zh-CN","zh-SG"],"meta":{"alternate":{"family":"Cabin, \'\u534E\u6587\u5B8B\u4F53\', STSong, serif"}}},{"locales":["zh-HK","zh-TW"],"meta":{"alternate":{"family":"Cabin, \'\u5137\u5B8B Pro\', LiSong Pro, serif"}}}]},"logo":{"id":"raleway","description":"","tags":[],"meta":{"order":32,"logo":{"id":"raleway","name":"Raleway","url":"//fonts.googleapis.com/css?family=Raleway:700,400&display=swap","family":"\'Raleway\', arial, Sans-Serif","size":14,"weight":400,"weights":[400,700],"styles":{"letterSpacing":"4px","textTransform":"uppercase","fontWeight":400,"fontSize":"xlarge"}}}}}},"theme":"Theme27"}'
);
Core.utils.deferBootstrap(
  {
    elId: "bs-5",
    componentName: "@widget/GALLERY/bs-gallery2-Gallery",
    props: JSON.parse(
      '{"upgradeable":false,"preset":"gallery2","order":0,"id":"9ecdea1b-aa8b-4b08-a513-54de70a7705c","galleryImages":[{"image":{"hasAlpha":false,"width":"100%","left":"0%","height":"100%","position":"50% 50%","scale":0.07037943696450429,"editedAspectRatio":"1.5667074663402694","imageDimension":null,"overlayAlpha":0,"colors":[{"hex":"#ebe8ea","rgb":[235,232,234],"hsluv":[323.0760495971874,9.186614029951027,91.95287681847697],"distance":93.76897169257536},{"hex":"#e5ded9","rgb":[229,222,217],"hsluv":[47.52539676813503,15.740382853732937,88.57170622313488],"distance":90.27775949953077},{"hex":"#e4d7cb","rgb":[228,215,203],"hsluv":[52.14494016196526,24.45961814048824,86.40364807771364],"distance":88.99445694776793},{"hex":"#ebb191","rgb":[235,177,145],"hsluv":[36.45361374796549,61.87989341851205,76.50098555798641],"distance":82.7902349380264},{"hex":"#d79165","rgb":[215,145,101],"hsluv":[35.78923855869251,60.050235441155465,66.00625015074074],"distance":72.11068824640822},{"hex":"#b8a59c","rgb":[184,165,156],"hsluv":[37.59450087513404,13.981787007052334,68.86720468785407],"distance":70.3698125576569},{"hex":"#ce7c3f","rgb":[206,124,63],"hsluv":[34.79457808401347,79.95540653317654,59.57938793867524],"distance":67.67158019778182},{"hex":"#b79079","rgb":[183,144,121],"hsluv":[38.71987653181948,35.651397989506535,62.61394414352297],"distance":66.286639155062},{"hex":"#202237","rgb":[32,34,55],"hsluv":[263.0743051643136,29.35952288319034,13.916145261600256],"distance":17.582859508709053},{"hex":"#252024","rgb":[37,32,36],"hsluv":[316.568108274593,9.154294429386367,12.88184715404794],"distance":14.67663245330489},{"hex":"#1b1c24","rgb":[27,28,36],"hsluv":[261.58102901910166,14.216365819912216,10.434463491592567],"distance":12.582714043081292},{"hex":"#1c191a","rgb":[28,25,26],"hsluv":[346.7214114829721,4.796227851031772,9.079146359975319],"distance":10.52188417697564}],"top":"0%","oHeight":1634,"oWidth":2560,"filter":"NONE","image":"//img1.wsimg.com/isteam/ip/99c50270-63c0-4337-8a9d-d84b3263f0b3/adeolu-eletu-134758-unsplash%20(1).jpg","coordinates":{"x":0,"y":0},"rotation":"0"}},{"image":{"hasAlpha":false,"width":"100%","left":"0%","height":"100%","position":"50% 50%","scale":0.06647398843930635,"editedAspectRatio":"1.4450867052023122","imageDimension":null,"overlayAlpha":0,"colors":[{"hex":"#e5ecf2","rgb":[229,236,242],"hsluv":[232.96583339089403,32.80721803748571,92.7187883381228],"distance":96.64663745684608},{"hex":"#f1efed","rgb":[241,239,237],"hsluv":[55.20547269349704,9.576541776686883,94.21982894112575],"distance":95.33083165405415},{"hex":"#eee3d1","rgb":[238,227,209],"hsluv":[63.3492127459106,31.775634605010033,90.33750030198955],"distance":93.69103379789586},{"hex":"#e7ece8","rgb":[231,236,232],"hsluv":[135.90579046790953,5.522458763583537,92.60806412578788],"distance":93.53782608677932},{"hex":"#e1e5e8","rgb":[225,229,232],"hsluv":[229.76751400621876,12.710753024305015,90.40724255977521],"distance":92.31656095666743},{"hex":"#9ca7ae","rgb":[156,167,174],"hsluv":[227.30966751491857,13.428543620884037,67.60255864730883],"distance":69.57682875249422},{"hex":"#a5978e","rgb":[165,151,142],"hsluv":[43.98091469117226,13.807166959401865,63.186266244099144],"distance":64.6891521475148},{"hex":"#13588d","rgb":[19,88,141],"hsluv":[246.86516206468426,94.38825581303364,35.92086136308214],"distance":46.0454235056763},{"hex":"#705545","rgb":[112,85,69],"hsluv":[38.265000016488294,39.062873789862614,38.35369923973088],"distance":42.36627828542961},{"hex":"#784c37","rgb":[120,76,55],"hsluv":[31.17662078411808,56.05206018054344,36.67204304354921],"distance":42.36385078600388},{"hex":"#5f5850","rgb":[95,88,80],"hsluv":[56.06333740797056,17.355913710150517,37.681983151168524],"distance":39.573306014983494},{"hex":"#1c1a1a","rgb":[28,26,26],"hsluv":[12.177050630066635,2.30655751336582,9.431557236389057],"distance":9.696038128364714}],"top":"0%","oHeight":1730,"oWidth":2500,"filter":"NONE","image":"//img1.wsimg.com/isteam/ip/99c50270-63c0-4337-8a9d-d84b3263f0b3/accounting-analysis-analytics-938963.jpg","coordinates":{"x":0,"y":7.105427357601002e-15},"rotation":"0"}},{"image":{"hasAlpha":false,"width":"NaN%","left":"NaN%","height":"NaN%","position":"50% 50%","editedAspectRatio":"0.66640625","imageDimension":null,"overlayAlpha":0,"colors":[{"hex":"#e2e3e6","rgb":[226,227,230],"hsluv":[253.53075132620057,9.999007528350116,89.92592936573094],"distance":91.63008220558318},{"hex":"#e1dedc","rgb":[225,222,220],"hsluv":[46.49234123602716,6.4998942480263056,88.33871661395533],"distance":89.11785143108025},{"hex":"#dedcdd","rgb":[222,220,221],"hsluv":[333.5764471777625,3.927502374934321,87.63252366504034],"distance":88.95187514469423},{"hex":"#ada098","rgb":[173,160,152],"hsluv":[43.33793908937899,11.829533464461411,66.50518402298064],"distance":67.80852053356395},{"hex":"#a49fa3","rgb":[164,159,163],"hsluv":[316.1653990937285,3.341272503027088,65.77152104957337],"distance":66.98388551958088},{"hex":"#b1927c","rgb":[177,146,124],"hsluv":[43.279978842879444,32.362658615302145,62.585350636301584],"distance":65.94183866128424},{"hex":"#969ca4","rgb":[150,156,164],"hsluv":[242.21742804076672,9.098869682656366,63.88352879618259],"distance":65.46624195345035},{"hex":"#bc8155","rgb":[188,129,85],"hsluv":[38.87738803427158,63.04523150048203,58.80568862251549],"distance":65.21820451710335},{"hex":"#814931","rgb":[129,73,49],"hsluv":[27.822146657698497,65.0920179271763,37.070842748263715],"distance":43.657328281697175},{"hex":"#5a5e64","rgb":[90,94,100],"hsluv":[244.44087471634344,9.84032728415901,39.5953384190165],"distance":41.25837357720002},{"hex":"#232c32","rgb":[35,44,50],"hsluv":[230.7327641099942,32.816286693516226,17.329989183963434],"distance":21.25254219806504},{"hex":"#171615","rgb":[23,22,21],"hsluv":[54.627363412917816,6.424784006912825,7.2758711120101855],"distance":7.275871112010185}],"top":"NaN%","oHeight":2560,"oWidth":1706,"filter":"NONE","image":"//img1.wsimg.com/isteam/ip/99c50270-63c0-4337-8a9d-d84b3263f0b3/stil-1220500-unsplash.jpg","coordinates":{"x":null,"y":null},"rotation":"0"}}],"viewDevice":null,"staticContent":{"showMore":"Show More","demoCaption1":"Use captions to provide more information about your photos","demoCaption2":"Captions can prompt viewers to act. You can even insert a link","demoCaption3":"Use the caption to call out things the viewer may not notice","showLess":"Show Less"},"widgetId":"9ecdea1b-aa8b-4b08-a513-54de70a7705c","section":"default","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"widgetId":"9ecdea1b-aa8b-4b08-a513-54de70a7705c","widgetType":"GALLERY","widgetPreset":"gallery2","group":"Widget","groupType":"Banner","section":"default","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-5",
    radpack: "@widget/GALLERY/bs-gallery2-Gallery",
  },
  false
);
Core.utils.deferBootstrap(
  {
    elId: "bs-6",
    componentName: "@widget/REVIEWS/bs-Component",
    props: JSON.parse(
      '{"hasBgImage":false,"upgradeable":false,"preset":"reviews1","id":"8c712872-33dd-4898-9976-6eca4f9afd29","planType":"businessPlus","market":"en-US","publishDate":"2022-08-25T22:06:24.980Z","fbPageId":null,"gmbShowPendingMessage":false,"publishAfterLastUpgrade":false,"providerType":"gmb","isReseller":false,"accountId":"ae15f291-24c0-11ed-82b9-3417ebe73f23","viewDevice":null,"sectionTitle":"Reviews","background":{},"staticContent":{"txtPendingValidation":"Pending Validation","reviewTitle":"Title","add":"Add","doesNotRecommend":"Doesn\'t recommend","noWrittenReviews":"This customer did not write a review.","connectionSuccess":"Successfully Connected!","cantConnect":"Why can\'t I connect yet?","reviewDate":"Review Date","productReview":"{totalReviews} Product Review","viewAllProductReviews":"View All {totalReviews} Product Reviews","upgradeMessage":"Your site needs to have an online store to use {provider} reviews","productReviews":"{totalReviews} Product Reviews","goToProduct":"Go to {productName}","anonymous":"Anonymous","gmb3Days":"It may take up to 3 days to validate your business. Until then, reviews will not appear on your site.","noReviewsYet":"There are no reviews yet.","reviewerName":"Reviewer Name","basedOn":"Based on the opinion of {reviewCount} people","photo":"Photo","gmbAwaitingData":"We are waiting for data. Please check back later","reviewLink":"Review Link","basedOnOne":"Based on the opinion of 1 person","gmbUnderReview":"Google is reviewing your business info. We\'ll let you know when your listing is live.","gmbPublishMessage":"Your website needs to be published before connecting to Google My Business.","sourceMsgStatic":"Add reviews manually","manualReviews":"Reviews","ratingNone":"None","reviewRating":"Rating","percentRecommend":"{percent} recommend","connectMsg":"To show reviews on your site, connect your account to {provider}","twentyFourHourLag":"Data may take up to 24 hours to display.","recommends":"Recommends","reviewFirst":"Be the first to leave a review","review":"{totalReviews} Review","publishMessage":"Your website needs to be published before connecting to {provider}","sourceMsgDynamic":"Connect to external source","reviewBody":"Review","upgradeNow":"Add Store Now","viewMore":"View More","reviews":"{totalReviews} Reviews","cantConnectMsg":"Your website needs to be published before connecting to {provider}","comingSoon":"Reviews coming soon!","readFullReview":"Read full review","labelForDeleteManualReview":"Delete Review","gmbNoReviews":"You are successfully connected but there are no reviews yet.","connectBtnText":"Connect to {provider}","viewAllReviews":"View All {totalReviews} Reviews"},"websiteId":"86c96b2b-f5e9-48de-923b-0e4c326c8bf4","sourceType":"static","manualReviews":[{"photo":{},"title":"","body":"Professional, accurate in filing and worry free service","rating":"5","name":"","date":""},{"photo":{},"title":"","body":"Easy to communicate and always there when I need them. Highly recommended!","rating":"5","name":"Anonymous","date":""},{"photo":{},"title":"","body":"I can\'t say enough about how professional they are. They help me to make informed decisions.","rating":"5","name":"Anonymous","date":""}],"widgetId":"8c712872-33dd-4898-9976-6eca4f9afd29","section":"default","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"order":2,"widgetId":"8c712872-33dd-4898-9976-6eca4f9afd29","widgetType":"REVIEWS","widgetPreset":"reviews1","group":"Section","groupType":"Banner","section":"default","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-5",
    radpack: "@widget/REVIEWS/bs-Component",
  },
  false
);
Core.utils.deferBootstrap(
  {
    elId: "bs-7",
    componentName: "@widget/SUBSCRIBE/bs-subscribe1-subscribe-form",
    props: JSON.parse(
      '{"upgradeable":false,"preset":"subscribe1","id":"37a4ae72-b47d-4ab0-a82a-14843f2ef27d","websiteId":"86c96b2b-f5e9-48de-923b-0e4c326c8bf4","accountId":"ae15f291-24c0-11ed-82b9-3417ebe73f23","hasNonCommercePlan":true,"couponToggleHidden":false,"sectionTitle":"Sign up for updates","staticContent":{"defaultButtonLabel":"Sign Up","emailPlaceholderText":"Email Address","verificationText":"To let us know it\'s really you and that you\'d like to receive emails from us, please click the link in the confirmation email we just sent you. You can unsubscribe from these emails at any time.","emailErrorMessage":"Please enter a valid email address."},"confirmationMessage":"Great, now please verify your email","couponConfirmationMessage":"Thanks so much for signing up!","description":"Subscribe to hear more about our company updates, tax tips, and financing options.","couponDescription":"Get 10% off your first purchase when you sign up for our newsletter!","inputPlaceholder":"Email Address","subscribeButtonLabel":"Sign up","couponToggle":true,"widgetId":"37a4ae72-b47d-4ab0-a82a-14843f2ef27d","section":"default","category":"neutral","locale":"en-US","env":"production","renderMode":"PUBLISH"}'
    ),
    context: JSON.parse(
      '{"order":3,"widgetId":"37a4ae72-b47d-4ab0-a82a-14843f2ef27d","widgetType":"SUBSCRIBE","widgetPreset":"subscribe1","group":"Section","groupType":"Default","section":"default","category":"neutral","fontSize":"medium","fontFamily":"alternate","websiteThemeOverrides":{"ButtonSecondary":{"value":{"shape":"SQUARE","color":"PRIMARY","fill":"SOLID","decoration":"NONE","shadow":"NONE","size":"small"}},"ButtonPrimary":{"value":{"color":"PRIMARY","fill":"SOLID","shape":"SQUARE","decoration":"NONE","shadow":"NONE","size":"default"}},"ButtonSpotlight":{"value":{"shape":"SQUARE","decoration":"NONE","shadow":"NONE","color":"PRIMARY"}},"ButtonExternal":{"value":{"shape":"SQUARE"}}},"widgetThemeOverrides":{}}'
    ),
    contextKey: "context-bs-5",
    radpack: "@widget/SUBSCRIBE/bs-subscribe1-subscribe-form",
  },
  false
);
window.wsb["CookieBannerScript"] = function (e) {
  let { id: t, acceptCookie: o, dismissCookie: a } = e;
  const n = 864e5;
  let i, l, r;
  function s(e) {
    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 60;
    const o = new Date();
    o.setTime(o.getTime() + n * t);
    const a = `expires=${o.toUTCString()}`;
    document.cookie = `${e}=true;${a};path=/`;
  }
  function c(e) {
    return document.cookie.includes(e);
  }
  function p() {
    l && l.removeEventListener("click", g),
      r && r.removeEventListener("click", d),
      (i.style.display = "none");
  }
  function g(e) {
    e.preventDefault(), u(), s(a), s(o), p();
  }
  function d(e) {
    var t;
    e.preventDefault(),
      s(a),
      c(o) &&
        ((t = o),
        (document.cookie = `${t}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`)),
      p();
  }
  function u() {
    (window._allowCT = !0),
      window._allowCTListener && window._allowCTListener.forEach((e) => e());
  }
  c(o)
    ? u()
    : c(a) ||
      setTimeout(() => {
        (i = document.getElementById(`${t}-banner`)),
          (l = document.getElementById(`${t}-accept`)),
          (r = document.getElementById(`${t}-decline`)),
          l && l.addEventListener("click", g),
          r && r.addEventListener("click", d),
          (i.style.transform = "translateY(-500px)");
      }, 200);
};
window.wsb["CookieBannerScript"](
  JSON.parse(
    '{"id":"86e5ea4e-873b-4ef4-9b72-602bce5c147e","dismissCookie":"cookie_warning_dismissed","acceptCookie":"cookie_terms_accepted"}'
  )
);
document
  .getElementById("page-25098")
  .addEventListener("click", function () {}, false);
var t = document.createElement("script");
(t.type = "text/javascript"),
  t.addEventListener("load", () => {
    window.tti.calculateTTI(({ name: t, value: e } = {}) => {
      let i = {
        wam_site_hasPopupWidget: false,
        wam_site_hasMessagingWidget: false,
        wam_site_headerTreatment: "Inset",
        wam_site_hasSlideshow: false,
        wam_site_hasFreemiumBanner: false,
        wam_site_homepageFirstWidgetType: "GALLERY",
        wam_site_homepageFirstWidgetPreset: "gallery1",
        wam_site_businessCategory: "accountingbookkeeping",
        wam_site_theme: "layout27",
        wam_site_locale: "en-US",
        wam_site_fontPack: "playfair-display",
        wam_site_cookieBannerEnabled: true,
        wam_site_membershipEnabled: false,
        wam_site_hasHomepageHTML: false,
        wam_site_hasHomepageShop: false,
        wam_site_hasHomepageOla: false,
        wam_site_hasHomepageBlog: false,
        wam_site_hasShop: false,
        wam_site_hasOla: false,
        wam_site_planType: "businessPlus",
        wam_site_isHomepage: false,
        wam_site_htmlWidget: false,
      };
      window.networkInfo &&
        window.networkInfo.downlink &&
        (i = Object.assign({}, i, {
          ["wam_site_networkSpeed"]: window.networkInfo.downlink.toFixed(2),
        })),
        window.tti.setCustomProperties(i),
        window.tti._collectVitals({ name: t, value: e });
    });
  }),
  t.setAttribute("src", "//img1.wsimg.com/traffic-assets/js/tccl-tti.min.js"),
  document.body.appendChild(t);
