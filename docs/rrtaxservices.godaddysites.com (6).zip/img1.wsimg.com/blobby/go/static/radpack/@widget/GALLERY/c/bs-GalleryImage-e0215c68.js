define(
  "@widget/GALLERY/c/bs-GalleryImage-e0215c68.js",
  ["exports"],
  function (e) {
    "use strict";
    const { Link: a } = (global.Core || guac["@wsb/guac-widget-core"])
        .components,
      c = (e) => {
        const c = (0,
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.utils.TCCLUtils
            .getTCCLString)({
            eid: "ux2.gallery.external_link.click",
            type: "click",
          }),
          { style: t } = e.imageProps,
          l = e.background
            ? (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component
                  .Background,
                e.imageProps
              )
            : (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Image,
                e.imageProps
              );
        return e.externalLink
          ? (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
              { style: t },
              (global.React || guac.react).createElement(
                a,
                { "data-tccl": c, linkData: e.externalLink },
                l
              )
            )
          : (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
              { style: t },
              l
            );
      };
    (c.propTypes = {
      imageProps: (global.PropTypes || guac["prop-types"]).object,
      background: (global.PropTypes || guac["prop-types"]).bool,
      externalLink: (global.PropTypes || guac["prop-types"]).object,
    }),
      (e.G = c);
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-GalleryImage-e0215c68.js.map
