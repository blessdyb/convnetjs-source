define(
  "@widget/REVIEWS/bs-Component-b68d670c.js",
  ["exports", "@wsb/guac-widget-shared@^1/lib/components/Carousel"],
  function (e, t) {
    "use strict";
    function a(e, t, a) {
      return (
        t in e
          ? Object.defineProperty(e, t, {
              value: a,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = a),
        e
      );
    }
    function o() {
      return (
        (o = Object.assign
          ? Object.assign.bind()
          : function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var a = arguments[t];
                for (var o in a)
                  Object.prototype.hasOwnProperty.call(a, o) && (e[o] = a[o]);
              }
              return e;
            }),
        o.apply(this, arguments)
      );
    }
    var r = (global.keyMirror || guac.keymirror)({
      REVIEWS_SECTION_TITLE_RENDERED: null,
      REVIEWS_NO_DATA_RENDERED: null,
      REVIEWS_NOT_CONNECTED_MSG: null,
      PENDING_VALIDATION_HEADER: null,
      PENDING_VALIDATION_CONTENT: null,
      WAITING_FOR_DATA_HEADER: null,
      WAITING_FOR_DATA_CONTENT: null,
      SECTION_BACKGROUND: null,
      REVIEWS_BUSINESS_NAME_RENDERED: null,
      REVIEWS_CONNECT_BUTTON: null,
      USER_REVIEW_RENDERED: null,
      STATIC_REVIEW_RENDERED: null,
      READ_MORE_RENDERED: null,
      PRODUCT_LINK_RENDERED: null,
      REVIEW_TITLE_RENDERED: null,
      REVIEWER_INFO_RENDERED: null,
      REVIEWER_INITIAL_RENDERED: null,
      REVIEWER_PHOTO_RENDERED: null,
      RECOMMENDATION_RENDERED: null,
      RECOMMENDATION_ICON_RENDERED: null,
      RECOMMENDATION_TEXT_RENDERED: null,
      RECOMMENDATION_DESC_RENDERED: null,
      RATING_RENDERED: null,
      LEFT_ARROW_RENDERED: null,
      RIGHT_ARROW_RENDERED: null,
      UPGRADE_TIER_MSG: null,
      REVIEWS_LOADER: null,
    });
    const n = "facebook",
      l = "yelp",
      i = "gmb",
      s = "yotpo",
      c = "manual",
      g = {
        facebook: "REVIEWS_FB_CONNECT_CLICKED",
        yelp: "REVIEWS_YELP_CONNECT_CLICKED",
        gmb: "REVIEWS_GMB_CONNECT_CLICKED",
        yotpo: "REVIEWS_YOTPO_CONNECT_CLICKED",
      },
      p = {
        facebook: "facebook2",
        yelp: "yelpLogoNegative",
        gmb: "gmb",
        yotpo: "yotpo",
      },
      d = {
        facebook: "facebook",
        yelp: "yelpLogoNegative",
        gmb: "gmb",
        yotpo: "yotpo",
      },
      u = { facebook: "fb", yelp: "yelp", gmb: "gmb", yotpo: "yotpo" },
      m = { positive: "fbRecommends", negative: "fbDoesNotRecommend" },
      b = { positive: "recommends", negative: "doesNotRecommend" },
      h = {
        facebook: "Facebook",
        gmb: "Google My Business",
        yelp: "Yelp",
        yotpo: "Yotpo",
      },
      E = {
        facebook:
          "https://graph.facebook.com/v3.0/{id}/picture?height=100&width=100",
      },
      y = {
        base: {
          facebook: "https://facebook.com",
          gmb: "https://maps.google.com",
          yelp: "https://www.yelp.com/biz",
        },
        photo: { facebook: "https://graph.facebook.com/v3.0/{id}/picture" },
      },
      R = "NOT_SETUP",
      w = "LOADING",
      v = "HAS_REVIEWS",
      C = "FAILED",
      f = "NO_REVIEWS",
      T = "CONNECTED",
      D = "NOT_CONNECTED",
      I = {
        reseller: {
          local: "dev-secureserver.net",
          development: "dev-secureserver.net",
          test: "test-secureserver.net",
          production: "secureserver.net",
        },
        godaddy: {
          local: "dev-godaddy.com",
          development: "dev-godaddy.com",
          test: "test-godaddy.com",
          production: "godaddy.com",
        },
      },
      N = "LEFT",
      _ = "RIGHT",
      P = {
        facebook:
          "https://dashboard.{rootDomain}/fbPageCreate/{accountId}?home={home}",
        gmb: "https://dashboard.{rootDomain}/account/{accountId}/gmb",
        yelp: "https://dashboard.{rootDomain}/account/{accountId}/yelp",
        yotpo:
          "https://{websiteId}.onlinestore.{rootDomain}/admin/general_settings/edit#reviews",
      },
      x = {
        yotpo:
          "https://launch.{rootDomain}/?account_uid={accountId}&path=plans",
      },
      M = { color: "section" },
      k = [s],
      O = [c],
      S = {
        topBar: {
          display: "flex",
          alignItems: "center",
          alignContent: "center",
          justifyContent: "center",
          cursor: "pointer",
          marginBottom: "large",
          "@xs-only": { boxShadow: "none", justifyContent: "center" },
          "@sm": { justifyContent: "center" },
        },
        overallRating: { marginLeft: "small" },
        ratingStar: {
          backgroundColor: "transparent",
          marginHorizontal: "medium",
          "@md": { marginHorizontal: "0px" },
        },
        overallRatingContainer: {
          display: "flex",
          flexDirection: "column",
          marginLeft: "small",
        },
        overallReviews: { lineHeight: "normal", marginTop: "xxsmall" },
        recommended: { fontWeight: "bold", lineHeight: "normal" },
        mobileTopBarContainer: {
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "0",
        },
        businessName: { marginBottom: "xxsmall", lineHeight: "normal" },
        pageLink: {
          display: "block",
          color: "section",
          ":hover": M,
          ":visited": M,
          textTransform: "none",
        },
        pageLinkContainer: {
          padding: "0",
          marginBottom: "medium",
          textAlign: "center",
        },
      };
    class U extends (global.React || guac.react).Component {
      generateReviewBarStyles() {
        const { provider: e } = this.props;
        return {
          linkProps: {
            tag: "a",
            target: k.includes(e) ? "_self" : "_blank",
            rel: k.includes(e) ? "alternate" : "noopener",
            style: { display: "block" },
          },
        };
      }
      getBusinessNameBlock() {
        const { businessName: e } = this.props;
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text.Major,
          {
            "data-aid": r.REVIEWS_BUSINESS_NAME_RENDERED,
            style: S.businessName,
            children: e,
          }
        );
      }
      getRecommendationPercentage() {
        const { positiveRecommendations: e, negativeRecommendations: t } =
          this.props;
        return e > 0 ? Math.ceil((100 * e) / (e + t)) : 0;
      }
      getMobileRatingBar() {
        const {
          provider: e,
          overallRating: t,
          positiveRecommendations: a,
          staticContent: o,
          negativeRecommendations: l,
        } = this.props;
        if (e === n && a > 0) {
          const e = this.getRecommendationPercentage(),
            t = a + l;
          return (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            {
              "data-aid": r.RECOMMENDATION_RENDERED,
              style: { ...S.topBar, flexDirection: "column" },
            },
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text
                .Major,
              {
                "data-aid": r.RECOMMENDATION_TEXT_RENDERED,
                style: S.recommended,
              },
              o.percentRecommend.replace("{percent}", `${e}%`)
            ),
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
              {
                "data-aid": r.RECOMMENDATION_DESC_RENDERED,
                style: {
                  ...S.overallReviews,
                  textAlign: "center",
                  marginBottom: "small",
                },
              },
              1 === t ? o.basedOnOne : o.basedOn.replace("{reviewCount}", t)
            )
          );
        }
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
          { style: S.topBar },
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Heading
              .Major,
            { style: S.overallRating },
            t.toFixed(1)
          ),
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component.Rating,
            { "data-aid": r.RATING_RENDERED, rating: t, style: S.ratingStar }
          )
        );
      }
      getDesktopRatingBar() {
        const {
          provider: e,
          positiveRecommendations: t,
          negativeRecommendations: a,
          overallRating: o,
          totalReviews: l,
          staticContent: i,
        } = this.props;
        let c = 1 === l ? i.review : i.reviews;
        if (
          (e === s && (c = 1 === l ? i.productReview : i.productReviews),
          e === n && t > 0)
        ) {
          const e = this.getRecommendationPercentage(),
            o = t + a;
          return (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            {
              "data-aid": r.RECOMMENDATION_RENDERED,
              style: S.overallRatingContainer,
            },
            this.getBusinessNameBlock(),
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text
                .Major,
              {
                "data-aid": r.RECOMMENDATION_TEXT_RENDERED,
                style: S.recommended,
              },
              i.percentRecommend.replace("{percent}", `${e}%`)
            ),
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
              {
                "data-aid": r.RECOMMENDATION_DESC_RENDERED,
                style: S.overallReviews,
              },
              1 === o ? i.basedOnOne : i.basedOn.replace("{reviewCount}", o)
            )
          );
        }
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
          { style: S.overallRatingContainer },
          this.getBusinessNameBlock(),
          o > 0 &&
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component
                .Rating,
              { "data-aid": r.RATING_RENDERED, rating: o, style: S.ratingStar }
            ),
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
            { style: S.overallReviews },
            c.replace("{totalReviews}", l)
          )
        );
      }
      render() {
        const {
          provider: e,
          overallRating: t,
          totalReviews: a,
          businessName: l,
          positiveRecommendations: i,
          negativeRecommendations: c,
          pageLink: g,
          staticContent: d,
          isMobile: u,
          hasBgImage: m,
          category: b,
          section: h,
        } = this.props;
        if (O.includes(e)) return null;
        const E = this.generateReviewBarStyles();
        E.linkProps.href = g;
        const y = e === s ? d.viewAllProductReviews : d.viewAllReviews,
          R = e === n && i > 0 ? i + c : a;
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Container,
          { category: m ? "accent" : b, section: m ? "overlay" : h },
          !u &&
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                .Element,
              o({}, E.linkProps, { style: { "text-decoration-line": "none" } }),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Block,
                { style: S.topBar },
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  { style: { marginTop: "xxsmall" } },
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Icon,
                    { icon: p[e], size: "xlarge" }
                  )
                ),
                e !== n &&
                  t > 0 &&
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Heading.Major,
                    { style: S.overallRating },
                    t.toFixed(1)
                  ),
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  { style: S.overallRatingContainer },
                  this.getDesktopRatingBar()
                )
              )
            ),
          u &&
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                .Container,
              { style: S.mobileTopBarContainer },
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text
                  .Major,
                {
                  "data-aid": r.REVIEWS_BUSINESS_NAME_RENDERED,
                  style: { marginBottom: "xxsmall", textAlign: "center" },
                  children: l,
                }
              ),
              this.getMobileRatingBar(),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Container,
                { style: S.pageLinkContainer },
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Element,
                  { tag: "a", target: "_blank", href: g, style: S.pageLink },
                  y.replace("{totalReviews}", 1 === R ? "" : R)
                )
              )
            )
        );
      }
    }
    a(U, "propTypes", {
      provider: (global.PropTypes || guac["prop-types"]).string,
      overallRating: (global.PropTypes || guac["prop-types"]).number,
      totalReviews: (global.PropTypes || guac["prop-types"]).number,
      isMobile: (global.PropTypes || guac["prop-types"]).bool,
      pageLink: (global.PropTypes || guac["prop-types"]).string,
      staticContent: (global.PropTypes || guac["prop-types"]).object.isRequired,
      hasBgImage: (global.PropTypes || guac["prop-types"]).bool,
      businessName: (global.PropTypes || guac["prop-types"]).string,
      category: (global.PropTypes || guac["prop-types"]).string,
      section: (global.PropTypes || guac["prop-types"]).string,
      positiveRecommendations: (global.PropTypes || guac["prop-types"]).number,
      negativeRecommendations: (global.PropTypes || guac["prop-types"]).number,
    }),
      a(U, "defaultProps", { provider: n, overallRating: 0, totalReviews: 0 });
    var A =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var o in a)
              Object.prototype.hasOwnProperty.call(a, o) && (e[o] = a[o]);
          }
          return e;
        },
      B = (function () {
        function e(e, t) {
          for (var a = 0; a < t.length; a++) {
            var o = t[a];
            (o.enumerable = o.enumerable || !1),
              (o.configurable = !0),
              "value" in o && (o.writable = !0),
              Object.defineProperty(e, o.key, o);
          }
        }
        return function (t, a, o) {
          return a && e(t.prototype, a), o && e(t, o), t;
        };
      })();
    function L(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function W(e, t) {
      if (!e)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called"
        );
      return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
    }
    var X = (function (e) {
      function t() {
        var e;
        L(this, t);
        for (var a = arguments.length, o = Array(a), r = 0; r < a; r++)
          o[r] = arguments[r];
        var n = W(
          this,
          (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(
            e,
            [this].concat(o)
          )
        );
        return (
          (n.state = {}),
          (n.styles = {
            ellipsis: {
              position: "fixed",
              visibility: "hidden",
              top: 0,
              left: 0,
            },
          }),
          (n.elements = {}),
          (n.onResize = n.onResize.bind(n)),
          (n.onTruncate = n.onTruncate.bind(n)),
          (n.calcTargetWidth = n.calcTargetWidth.bind(n)),
          (n.measureWidth = n.measureWidth.bind(n)),
          (n.getLines = n.getLines.bind(n)),
          (n.renderLine = n.renderLine.bind(n)),
          n
        );
      }
      return (
        (function (e, t) {
          if ("function" != typeof t && null !== t)
            throw new TypeError(
              "Super expression must either be null or a function, not " +
                typeof t
            );
          (e.prototype = Object.create(t && t.prototype, {
            constructor: {
              value: e,
              enumerable: !1,
              writable: !0,
              configurable: !0,
            },
          })),
            t &&
              (Object.setPrototypeOf
                ? Object.setPrototypeOf(e, t)
                : (e.__proto__ = t));
        })(t, (global.React || guac.react).Component),
        B(t, [
          {
            key: "componentDidMount",
            value: function () {
              var e = this.elements.text,
                t = this.calcTargetWidth,
                a = this.onResize,
                o = document.createElement("canvas");
              (this.canvasContext = o.getContext("2d")),
                t(function () {
                  e && e.parentNode.removeChild(e);
                }),
                window.addEventListener("resize", a);
            },
          },
          {
            key: "componentDidUpdate",
            value: function (e) {
              this.props.children !== e.children && this.forceUpdate(),
                this.props.width !== e.width && this.calcTargetWidth();
            },
          },
          {
            key: "componentWillUnmount",
            value: function () {
              var e = this.elements.ellipsis,
                t = this.onResize,
                a = this.timeout;
              e.parentNode.removeChild(e),
                window.removeEventListener("resize", t),
                window.cancelAnimationFrame(a);
            },
          },
          {
            key: "innerText",
            value: function (e) {
              var t = document.createElement("div"),
                a =
                  "innerText" in window.HTMLElement.prototype
                    ? "innerText"
                    : "textContent";
              t.innerHTML = e.innerHTML.replace(/\r\n|\r|\n/g, " ");
              var o = t[a],
                r = document.createElement("div");
              return (
                (r.innerHTML = "foo<br/>bar"),
                "foo\nbar" !== r[a].replace(/\r\n|\r/g, "\n") &&
                  ((t.innerHTML = t.innerHTML.replace(/<br.*?[\/]?>/gi, "\n")),
                  (o = t[a])),
                o
              );
            },
          },
          {
            key: "onResize",
            value: function () {
              this.calcTargetWidth();
            },
          },
          {
            key: "onTruncate",
            value: function (e) {
              var t = this.props.onTruncate;
              "function" == typeof t &&
                (this.timeout = window.requestAnimationFrame(function () {
                  t(e);
                }));
            },
          },
          {
            key: "calcTargetWidth",
            value: function (e) {
              var t = this.elements.target,
                a = this.calcTargetWidth,
                o = this.canvasContext,
                r = this.props.width;
              if (t) {
                var n =
                  r || Math.floor(t.parentNode.getBoundingClientRect().width);
                if (!n)
                  return window.requestAnimationFrame(function () {
                    return a(e);
                  });
                var l = window.getComputedStyle(t),
                  i = [
                    l["font-weight"],
                    l["font-style"],
                    l["font-size"],
                    l["font-family"],
                  ].join(" ");
                (o.font = i), this.setState({ targetWidth: n }, e);
              }
            },
          },
          {
            key: "measureWidth",
            value: function (e) {
              return this.canvasContext.measureText(e).width;
            },
          },
          {
            key: "ellipsisWidth",
            value: function (e) {
              return e.offsetWidth;
            },
          },
          {
            key: "trimRight",
            value: function (e) {
              return e.replace(/\s+$/, "");
            },
          },
          {
            key: "getLines",
            value: function () {
              for (
                var e = this.elements,
                  t = this.props,
                  a = t.lines,
                  o = t.ellipsis,
                  r = t.trimWhitespace,
                  n = this.state.targetWidth,
                  l = this.innerText,
                  i = this.measureWidth,
                  s = this.onTruncate,
                  c = this.trimRight,
                  g = [],
                  p = l(e.text)
                    .split("\n")
                    .map(function (e) {
                      return e.split(" ");
                    }),
                  d = !0,
                  u = this.ellipsisWidth(this.elements.ellipsis),
                  m = 1;
                m <= a;
                m++
              ) {
                var b = p[0];
                if (0 !== b.length) {
                  var h = b.join(" ");
                  if (i(h) <= n && 1 === p.length) {
                    (d = !1), g.push(h);
                    break;
                  }
                  if (m === a) {
                    for (
                      var E = b.join(" "), y = 0, R = E.length - 1;
                      y <= R;

                    ) {
                      var w = Math.floor((y + R) / 2);
                      i(E.slice(0, w + 1)) + u <= n ? (y = w + 1) : (R = w - 1);
                    }
                    var v = E.slice(0, y);
                    if (r)
                      for (v = c(v); !v.length && g.length; ) {
                        v = c(g.pop());
                      }
                    h = (global.React || guac.react).createElement(
                      "span",
                      null,
                      v,
                      o
                    );
                  } else {
                    for (var C = 0, f = b.length - 1; C <= f; ) {
                      var T = Math.floor((C + f) / 2);
                      i(b.slice(0, T + 1).join(" ")) <= n
                        ? (C = T + 1)
                        : (f = T - 1);
                    }
                    if (0 === C) {
                      m = a - 1;
                      continue;
                    }
                    (h = b.slice(0, C).join(" ")), p[0].splice(0, C);
                  }
                  g.push(h);
                } else g.push(), p.shift(), m--;
              }
              return s(d), g;
            },
          },
          {
            key: "renderLine",
            value: function (e, t, a) {
              if (t === a.length - 1)
                return (global.React || guac.react).createElement(
                  "span",
                  { key: t },
                  e
                );
              var o = (global.React || guac.react).createElement("br", {
                key: t + "br",
              });
              return e
                ? [
                    (global.React || guac.react).createElement(
                      "span",
                      { key: t },
                      e
                    ),
                    o,
                  ]
                : o;
            },
          },
          {
            key: "render",
            value: function () {
              var e = this,
                t = this.elements.target,
                a = this.props,
                o = a.children,
                r = a.ellipsis,
                n = a.lines,
                l = (function (e, t) {
                  var a = {};
                  for (var o in e)
                    t.indexOf(o) >= 0 ||
                      (Object.prototype.hasOwnProperty.call(e, o) &&
                        (a[o] = e[o]));
                  return a;
                })(a, ["children", "ellipsis", "lines"]),
                i = this.state.targetWidth,
                s = this.getLines,
                c = this.renderLine,
                g = this.onTruncate,
                p = void 0;
              return (
                "undefined" != typeof window &&
                  !(!t || !i) &&
                  (n > 0 ? (p = s().map(c)) : ((p = o), g(!1))),
                delete l.onTruncate,
                delete l.trimWhitespace,
                (global.React || guac.react).createElement(
                  "span",
                  A({}, l, {
                    ref: function (t) {
                      e.elements.target = t;
                    },
                  }),
                  (global.React || guac.react).createElement("span", null, p),
                  (global.React || guac.react).createElement(
                    "span",
                    {
                      ref: function (t) {
                        e.elements.text = t;
                      },
                    },
                    o
                  ),
                  (global.React || guac.react).createElement(
                    "span",
                    {
                      ref: function (t) {
                        e.elements.ellipsis = t;
                      },
                      style: this.styles.ellipsis,
                    },
                    r
                  )
                )
              );
            },
          },
        ]),
        t
      );
    })();
    (X.propTypes = {
      children: (global.PropTypes || guac["prop-types"]).node,
      ellipsis: (global.PropTypes || guac["prop-types"]).node,
      lines: (global.PropTypes || guac["prop-types"]).oneOfType([
        (global.PropTypes || guac["prop-types"]).oneOf([!1]),
        (global.PropTypes || guac["prop-types"]).number,
      ]),
      trimWhitespace: (global.PropTypes || guac["prop-types"]).bool,
      width: (global.PropTypes || guac["prop-types"]).number,
      onTruncate: (global.PropTypes || guac["prop-types"]).func,
    }),
      (X.defaultProps = {
        children: "",
        ellipsis: "…",
        lines: 1,
        trimWhitespace: !1,
        width: 0,
      });
    const H = [s],
      j = 240,
      V = 240,
      F = {
        common: {
          display: "flex",
          flexGrow: "1",
          flexShrink: "0",
          flexBasis: "auto",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "space-between",
        },
        topContainer: {
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        },
        photoContainer: {
          width: "100px",
          height: "100px",
          borderRadius: "50%",
          backgroundColor: "rgba(240,240,240,0.8)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
        },
        photoStyles: {
          width: "100px",
          height: "100px",
          display: "inline-block",
        },
        firstInitial: {
          color: "#CBCBCB",
          lineHeight: "1",
          padding: "medium",
          fontSize: "xxxlarge",
        },
        reviewBodyContainer: {
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          paddingHorizontal: "medium",
          paddingVertical: "medium",
          textTransform: "none",
          flexGrow: 2,
          width: "100%",
        },
        reviewTitle: {
          marginBottom: "small",
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
          lineHeight: "normal",
        },
        sharedReviewContent: { lineHeight: "1.3", minHeight: "42px" },
        fullReviewOverlay: { overflowY: "auto", height: "100%" },
        reviewerContainer: {
          paddingHorizontal: "medium",
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          "@xs-only": { marginTop: "0" },
        },
        reviewer: {
          paddingHorizontal: "small",
          fontSize: "xsmall",
          lineHeight: "normal",
        },
        recommendationContainer: {
          paddingTop: "medium",
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        },
        icons: {
          facebook: { color: "#4267B2", height: "25px", width: "25px" },
          recommendation: { width: "20px" },
        },
        fullReview: {
          position: "absolute",
          width: "100%",
          height: "100%",
          top: "100%",
          opacity: 0,
          left: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "action",
          color: "action",
          padding: "small",
          transition: "all 0.3s ease",
          "@md": { padding: "medium" },
        },
        fullReviewHover: {
          overflow: "hidden",
          "@md": {
            ":hover": { ".fullreview": { opacity: 1, top: 0, zIndex: 1 } },
          },
        },
        fullReviewClose: {
          position: "absolute",
          top: "16px",
          right: "16px",
          cursor: "pointer",
        },
        fullReviewOverlayShowOnMobile: { opacity: 1, top: 0, zIndex: 1 },
        linkContainer: { marginTop: "small" },
        ratingStars: {
          marginTop: "medium",
          "@xs-only": { marginTop: "small" },
        },
      },
      G = [n, l, s, i],
      z = [c],
      $ = [s],
      q = ["positive", "negative"];
    class K extends (global.React || guac.react).Component {
      constructor() {
        super(...arguments),
          (this.state = {
            truncated: !1,
            imageFailed: !1,
            showFullReviewOverlay: !1,
            showExternalLink: !1,
          }),
          (this.handleTruncate = this.handleTruncate.bind(this)),
          (this.toggleFullReviewOverlay =
            this.toggleFullReviewOverlay.bind(this)),
          (this.handleImageError = this.handleImageError.bind(this)),
          (this.getTotalReviewLines = this.getTotalReviewLines.bind(this)),
          (this.cardComponent = (global.React || guac.react).createRef());
      }
      handleTruncate(e) {
        const { provider: t } = this.props;
        this.state.truncated !== e &&
          this.setState({ truncated: e, showExternalLink: G.includes(t) });
      }
      toggleFullReviewOverlay() {
        this.setState({
          showFullReviewOverlay: !this.state.showFullReviewOverlay,
        });
      }
      handleImageError() {
        this.setState({ imageFailed: !0 });
      }
      getReviewerPhoto(e, t) {
        const { sourceType: a } = this.props,
          { imageFailed: n } = this.state;
        let l, i;
        e.photo
          ? (i = e.photo)
          : ((l = e.imageData || {}), (i = l.image || ""));
        let s =
          i && (i.toLowerCase().startsWith("http") || i.startsWith("//"))
            ? i
            : null;
        const c = "dynamic" === a;
        e.metadata &&
          e.metadata.reviewerId &&
          E[t] &&
          (s = E[t].replace("{id}", e.metadata.reviewerId));
        const g = e.name ? e.name.charAt(0).toUpperCase() : null,
          p = c
            ? { src: s }
            : { imageData: { ...l, outputWidth: 100, outputHeight: 100 } };
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
          { style: F.photoContainer },
          s &&
            !n &&
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Image
                .Thumbnail,
              o(
                {
                  tag: "img",
                  "data-aid": r.REVIEWER_PHOTO_RENDERED,
                  style: F.photoStyles,
                  onError: this.handleImageError,
                },
                p
              )
            ),
          (!s || n) &&
            g &&
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                .Heading,
              {
                "data-aid": r.REVIEWER_INITIAL_RENDERED,
                children: g,
                style: F.firstInitial,
              }
            )
        );
      }
      getRatingBlock() {
        const {
          provider: e,
          data: t,
          staticContent: a,
          renderMode: o,
        } = this.props;
        if (e === n && t.recommendation && q.includes(t.recommendation))
          return (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            {
              "data-aid": r.RECOMMENDATION_RENDERED,
              style: F.recommendationContainer,
            },
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Icon,
              {
                "data-aid": r.RECOMMENDATION_ICON_RENDERED,
                icon: m[t.recommendation],
                style: F.icons.recommendation,
              }
            ),
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
              {
                "data-aid": r.RECOMMENDATION_TEXT_RENDERED,
                style: { paddingLeft: "small" },
              },
              a[b[t.recommendation]]
            )
          );
        const l =
          e === c &&
          o !==
            (global.Core || guac["@wsb/guac-widget-core"]).constants.renderModes
              .EDIT &&
          "0" === t.rating
            ? "hidden"
            : "visible";
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component.Rating,
          {
            "data-aid": r.RATING_RENDERED,
            style: { ...F.ratingStars, visibility: l },
            rating: t.rating,
          }
        );
      }
      getTruncatedLine(e, t) {
        let a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        return (global.React || guac.react).createElement(
          X,
          {
            lines: 1,
            ellipsis: a ? '..."' : "...",
            trimWhitespace: !0,
            width: e ? j : V,
          },
          `${t}`
        );
      }
      sanitizeLink(e, t) {
        return H.includes(t) || !e || e.startsWith("http") ? e : `//${e}`;
      }
      componentDidUpdate(e) {
        const { data: t } = this.props,
          { data: a } = e;
        (t.photo === a.photo &&
          (global._ || guac.lodash).get(t, "imageData.image") ===
            (global._ || guac.lodash).get(a, "imageData.image")) ||
          this.setState({ imageFailed: !1 });
      }
      componentDidMount() {
        const e =
            this.cardComponent.current &&
            (global.ReactDOM || guac["react-dom"]).findDOMNode(
              this.cardComponent.current
            ),
          t = (e && e.offsetWidth) || 0;
        this.setState({ currentCardWidth: t });
      }
      getTotalReviewLines(e) {
        const { isMobile: t, provider: a } = this.props,
          { currentCardWidth: o } = this.state;
        if (t || (!t && e)) return 3;
        return o && o <= 300 ? 2 : a === c ? 4 : 3;
      }
      render() {
        const {
            data: e,
            provider: t,
            isMobile: a,
            desktopMobilePreview: o,
            link: n,
            staticContent: l,
            market: i,
            cardHeight: s,
          } = this.props,
          {
            truncated: g,
            showExternalLink: p,
            showFullReviewOverlay: u,
          } = this.state,
          m = z.includes(t) && (global._ || guac.lodash).get(e, "link", !1),
          b = g && !(m || p),
          h = $.includes(t) && !!(e && e.metadata && e.metadata.product),
          E = $.includes(t) ? "0.6" : "1",
          y = (e && e.metadata && e.metadata.title) || "",
          R = this.getTotalReviewLines(m),
          w = t === c,
          v = {
            card: {
              textAlign: "center",
              borderWidth: "0px",
              textShadow: "none",
              position: "relative",
              boxShadow: "2px 6px 30px 0 rgba(0,0,0,0.18)",
              paddingVertical: "large",
              height: s,
              width: "290px",
              "@xs-only": { paddingVertical: "medium" },
            },
          },
          C = b ? F.fullReviewHover : {},
          f = u ? F.fullReviewOverlayShowOnMobile : {};
        a && (o || ((v.card.minWidth = "290px"), (v.card.width = "auto")));
        let T = ((e, t) => {
          if (!e || !Date.parse(e)) return "";
          if (/^\d{4}-\d{2}-\d{2}/.test(e)) {
            const a = e.split(/\D+/).map((e) => parseInt(e, 10));
            return (a[1] = a[1] - 1), new Date(...a).toLocaleDateString(t);
          }
          return new Date(e).toLocaleDateString(t);
        })(e.date, i);
        return (
          !T && w && e.date && (T = e.date),
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            null,
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Group.Card,
              {
                ref: this.cardComponent,
                style: { ...F.common, ...v.card, ...C },
              },
              b &&
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  {
                    style: { ...F.fullReview, ...f },
                    className: "fullreview",
                    category: "accent",
                    section: "overlay",
                  },
                  a &&
                    (global.React || guac.react).createElement(
                      (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                        .Icon,
                      {
                        icon: "close",
                        style: F.fullReviewClose,
                        onClick: this.toggleFullReviewOverlay,
                      }
                    ),
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Text,
                    {
                      children: e.body,
                      style: {
                        color: "action",
                        ...F.sharedReviewContent,
                        ...F.fullReviewOverlay,
                      },
                    }
                  )
                ),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Container,
                { style: F.topContainer },
                this.getReviewerPhoto(e, t),
                this.getRatingBlock()
              ),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Block,
                { style: F.reviewBodyContainer },
                h &&
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Link,
                    {
                      "data-aid": r.PRODUCT_LINK_RENDERED,
                      target: "_self",
                      href: this.sanitizeLink(e.link || n, t),
                    },
                    this.getTruncatedLine(a, e.metadata.product)
                  ),
                y &&
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Heading,
                    {
                      "data-aid": r.REVIEW_TITLE_RENDERED,
                      style: F.reviewTitle,
                    },
                    y
                  ),
                e.body &&
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Text,
                    {
                      style: { ...F.sharedReviewContent, opacity: E },
                      featured: !0,
                    },
                    (global.React || guac.react).createElement(
                      X,
                      {
                        "data-aid": r.USER_REVIEW_RENDERED,
                        lines: R,
                        ellipsis: '..."',
                        trimWhitespace: !0,
                        width: a ? j : V,
                        onTruncate: this.handleTruncate,
                      },
                      `"${e.body}"`
                    )
                  ),
                !e.body &&
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Details,
                    { "data-aid": r.STATIC_REVIEW_RENDERED },
                    l.noWrittenReviews
                  ),
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  { style: { ...F.linkContainer } },
                  (m || p) &&
                    (global.React || guac.react).createElement(
                      (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                        .MoreLink.Forward,
                      {
                        "data-aid": r.READ_MORE_RENDERED,
                        target: h ? "_self" : "_blank",
                        href: this.sanitizeLink(e.link || n, t),
                      },
                      l.readFullReview
                    ),
                  a &&
                    g &&
                    !(m || p) &&
                    (global.React || guac.react).createElement(
                      (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                        .Link,
                      {
                        tag: "span",
                        onClick: this.toggleFullReviewOverlay,
                        children: l.viewMore || "View More",
                      }
                    )
                )
              ),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Block,
                { style: F.reviewerContainer },
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Icon,
                  { icon: d[t], size: "medium", style: F.icons[t] }
                ),
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Details.Minor,
                  {
                    "data-aid": r.REVIEWER_INFO_RENDERED,
                    tag: "p",
                    style: F.reviewer,
                  },
                  (global.React || guac.react).createElement(
                    "strong",
                    null,
                    e.name,
                    e.name && T ? " - " : ""
                  ),
                  T
                )
              )
            )
          )
        );
      }
    }
    a(K, "propTypes", {
      data: (global.PropTypes || guac["prop-types"]).object.isRequired,
      provider: (global.PropTypes || guac["prop-types"]).string.isRequired,
      link: (global.PropTypes || guac["prop-types"]).string,
      isMobile: (global.PropTypes || guac["prop-types"]).bool,
      nextPageHandler: (global.PropTypes || guac["prop-types"]).func,
      previousPageHandler: (global.PropTypes || guac["prop-types"]).func,
      desktopMobilePreview: (global.PropTypes || guac["prop-types"]).bool,
      staticContent: (global.PropTypes || guac["prop-types"]).object,
      renderMode: (global.PropTypes || guac["prop-types"]).string.isRequired,
      market: (global.PropTypes || guac["prop-types"]).string,
      sourceType: (global.PropTypes || guac["prop-types"]).string,
      cardHeight: (global.PropTypes || guac["prop-types"]).string,
    });
    const Y = "static",
      { MatchMedia: J } = (global.Core || guac["@wsb/guac-widget-core"]).UX,
      Z = "290px",
      Q = n,
      ee = [i, l],
      te = [s],
      ae = ["commerce", "managedStandardCommerce"],
      oe = { small: 430, medium: 440, large: 460, xlarge: 480 },
      re = {
        container: {
          textAlign: "center",
          display: "flex",
          flexDirection: "column",
        },
        cardsContainer: { position: "relative" },
        arrow: {
          width: "medium",
          position: "absolute",
          top: "50%",
          zIndex: 1,
          cursor: "pointer",
          color: "section",
          ":hover": { color: "rgba(288, 288, 288, 0.6)" },
        },
        grid: {
          alignItems: "center",
          justifyContent: "center",
          flexWrap: "nowrap",
        },
        cell: { flexGrow: 0 },
        paginationContainer: {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginTop: "xlarge",
        },
        pageDot: {
          width: "12px",
          height: "12px",
          borderRadius: "50%",
          margin: "xsmall",
          cursor: "pointer",
          backgroundColor: "sectionContrast",
          opacity: 0.6,
          boxShadow: "1px 2px 15px 0 rgba(0,0,0,0.18)",
        },
        selected: { opacity: 1 },
      };
    class ne extends (global.React || guac.react).Component {
      constructor() {
        super(...arguments),
          a(this, "handleMatchMedia", (e) => {
            const { viewDevice: t, renderMode: a } = this.props,
              o =
                a ===
                (global.Core || guac["@wsb/guac-widget-core"]).constants
                  .renderModes.PUBLISH
                  ? "xs" === e.size || "sm" === e.size
                  : /mobile/i.test(t);
            let r = 3;
            o ? (r = 1) : "md" === e.size && (r = 2),
              this.setState({ isMobile: o, cardsPerPage: r, size: e.size });
          }),
          (this.state = {
            data: {},
            currentPage: 1,
            pages: 0,
            provider: Q,
            state: w,
            isMobile: !1,
            cardsPerPage: 3,
            dummyData: !1,
            planUpgradeRequired: !1,
          });
      }
      updateCurrentPage(e) {
        return () => {
          this.setState({ currentPage: e });
        };
      }
      gotoPage() {
        let e =
          !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return () => {
          const { currentPage: t, pages: a } = this.state;
          let o = t + (e ? 1 : -1);
          e ? o > a && (o = 1) : o < 1 && (o = a),
            this.setState({ currentPage: o });
        };
      }
      getPageDotStyles(e) {
        const { currentPage: t } = this.state;
        let a = re.pageDot;
        return (
          t === e &&
            (a = (global._ || guac.lodash).merge({}, re.pageDot, re.selected)),
          a
        );
      }
      fetchData() {
        const {
          renderMode: e,
          providerType: t,
          planType: a,
          sourceType: o,
          manualReviews: r,
          staticContent: n,
        } = this.props;
        if (o === Y)
          if (r.length) {
            const e = (function () {
              let e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : [],
                t =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : "Anonymous";
              const a = { totalReviews: e.length, reviews: [] };
              return (
                e.length &&
                  (global._ || guac.lodash).each(e, (e) => {
                    a.reviews.push({
                      imageData: e.photo || {},
                      name: e.name || t,
                      date: e.date || "",
                      rating: e.rating,
                      body: e.body,
                      link: e.link || null,
                      metadata: { title: e.title },
                    });
                  }),
                a
              );
            })(r, n.anonymous);
            this.setState({ data: e, state: v }), this.updatePageCount(e);
          } else this.setState({ state: f });
        else if (te.includes(t) && !ae.includes(a))
          this.setState({ planUpgradeRequired: !0, state: R });
        else {
          this.setState({ planUpgradeRequired: !1, state: w });
          const t = this.getProvider();
          this.fetchDataForProviders((a) => {
            a
              ? (this.setState({ data: a, state: v }), this.updatePageCount(a))
              : e ===
                  (global.Core || guac["@wsb/guac-widget-core"]).constants
                    .renderModes.EDIT &&
                ee.includes(t) &&
                this.checkConnectStatusForProvider(t);
          });
        }
      }
      fetchDataForProviders(e) {
        const { websiteId: t, env: a } = this.props;
        let o = ((e, t, a) =>
          a === s
            ? `https://proxy.apps-api.instantpage.${I.reseller[e]}/v1/proxy/yotpo?websiteId=${t}`
            : `https://proxy.apps-api.instantpage.${I.reseller[e]}/v1/proxy/stats?id=${t}&source=${u[a]}`)(
          a,
          t,
          this.getProvider()
        );
        if ("production" !== String(a)) {
          const e = window.location.search.indexOf("dummy=true");
          e >= 0
            ? ((o = `${o}&${window.location.search.substring(e)}`),
              this.setState({ dummyData: !0 }))
            : this.setState({ dummyData: !1 });
        }
        if ("undefined" != typeof XMLHttpRequest) {
          const t = new XMLHttpRequest();
          (t.onreadystatechange = () => {
            if (4 === t.readyState) {
              if (200 === t.status) {
                const a = JSON.parse(t.responseText);
                return a.updateDate
                  ? (this.setState({ providerState: T }),
                    0 === a.reviews.length
                      ? (this.setState({ state: f }), void e(null))
                      : (this.setState({ state: v }), void e(a)))
                  : (this.setState({
                      state: R,
                      providerState: a.connected ? T : D,
                    }),
                    void e(null));
              }
              this.setState({ state: C });
            }
            e(null);
          }),
            t.open("GET", o, !0),
            t.send();
        }
      }
      checkConnectStatusForProvider(e) {
        const { accountId: t, env: a, isReseller: o } = this.props;
        if ("production" !== a && this.state.dummyData)
          this.setState({ providerState: T });
        else {
          const r = ((e, t, a) =>
            `https://proxy.apps-api.instantpage.${
              a ? I.reseller[e] : I.godaddy[e]
            }/v1/proxy/social?accountId=${t}`)(a, t, o);
          if ("undefined" != typeof XMLHttpRequest) {
            const t = new XMLHttpRequest();
            (t.onreadystatechange = () => {
              if (4 === t.readyState && 200 === t.status) {
                const a = JSON.parse(t.responseText);
                this.setConnectStatus(a, e);
              }
            }),
              t.open("GET", r, !0),
              (t.withCredentials = !0),
              t.send(null);
          }
        }
      }
      setConnectStatus(e) {
        const t =
          e &&
          e[arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i];
        if (t) {
          const e = (Object.keys(t) && Object.keys(t)[0]) || null,
            a = (e && t[e] && t[e].status) || D,
            o = "PUBLISHED" === a ? T : a;
          this.setState({ providerState: o });
        } else this.setState({ providerState: D });
      }
      componentDidUpdate(e, t) {
        (this.props.providerType !== e.providerType ||
          this.props.sourceType !== e.sourceType ||
          (this.props.sourceType === Y &&
            !(global._ || guac.lodash).isEqual(
              e.manualReviews,
              this.props.manualReviews
            )) ||
          this.state.cardsPerPage !== t.cardsPerPage) &&
          this.fetchData();
      }
      componentDidMount() {
        this.fetchData();
      }
      getProvider() {
        const { sourceType: e, providerType: t } = this.props;
        return e === Y ? c : t || Q;
      }
      updatePageCount(e) {
        const { cardsPerPage: t } = this.state;
        let a = 0;
        const o = e.reviews.length > 9 ? 9 : e.reviews.length;
        o && ((a = Math.floor(o / t)), (a += (o / t) % 1 > 0 ? 1 : 0)),
          this.setState({ pages: a });
      }
      getPageLink(e, t) {
        if (t === c) return null;
        let a = y.base[t];
        return (
          e &&
            e.metadata &&
            (e.metadata.pageId || e.metadata.link) &&
            (t === n
              ? (a = `${a}/${e.metadata.pageId}/reviews`)
              : t === i
              ? (a = `${a}/maps?cid=${e.metadata.pageId}`)
              : t === l
              ? (a = `${a}/${e.metadata.pageId}`)
              : t === s && (a = e.metadata.link || "/")),
          a
        );
      }
      getCardHeight() {
        const { fontScale: e } = this.props;
        return oe[e];
      }
      renderMobileCards(e, a) {
        const { data: o, isMobile: r } = this.state,
          {
            renderMode: n,
            viewDevice: l,
            staticContent: i,
            market: s,
            sourceType: c,
          } = this.props;
        if (!o.reviews) return null;
        const g =
            n ===
              (global.Core || guac["@wsb/guac-widget-core"]).constants
                .renderModes.PREVIEW &&
            "MOBILE_RENDER_DEVICE" === String(l) &&
            window.innerWidth > 768,
          p = o.reviews.length > 1,
          d = `${this.getCardHeight()}px`;
        return (global.React || guac.react).createElement(
          t.default,
          {
            slideHeight: d,
            viewportWidth: "100%",
            slideWidth: g ? "290px" : Z,
            cellPadding: 10,
            initialSlide: p ? 1 : 0,
            clickToNavigate: !1,
            infinite: p,
            dots: !1,
            arrows: !1,
            style: {
              slide: { opacity: "1", verticalAlign: "top" },
              selectedSlide: { opacity: "1" },
            },
          },
          (global._ || guac.lodash)
            .range(o.reviews.length)
            .map(
              (t) =>
                o.reviews &&
                o.reviews[t] &&
                (global.React || guac.react).createElement(K, {
                  desktopMobilePreview: g,
                  key: `mobile-review-card-${t}`,
                  data: o.reviews[t],
                  provider: e,
                  isMobile: r,
                  market: s,
                  staticContent: i,
                  renderMode: n,
                  link: a,
                  sourceType: c,
                  cardHeight: d,
                })
            )
        );
      }
      getCards() {
        const {
            currentPage: e,
            data: t,
            isMobile: a,
            cardsPerPage: o,
          } = this.state,
          {
            renderMode: r,
            staticContent: n,
            market: l,
            sourceType: i,
          } = this.props,
          s = this.getProvider(),
          c = e * o,
          g = this.getPageLink(t, s);
        return a
          ? this.renderMobileCards(s, g)
          : (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component.Grid,
              { style: re.grid },
              (global._ || guac.lodash)
                .takeRight([c - 3, c - 2, c - 1], o)
                .map(
                  (e) =>
                    t.reviews &&
                    t.reviews[e] &&
                    (global.React || guac.react).createElement(
                      (global.Core || guac["@wsb/guac-widget-core"]).UX2
                        .Component.Grid.Cell,
                      { key: e, style: re.cell },
                      (global.React || guac.react).createElement(K, {
                        data: t.reviews[e],
                        provider: s,
                        isMobile: a,
                        nextPageHandler: this.gotoPage(!0),
                        previousPageHandler: this.gotoPage(!1),
                        staticContent: n,
                        market: l,
                        renderMode: r,
                        link: g,
                        sourceType: i,
                        cardHeight: `${this.getCardHeight()}px`,
                      })
                    )
                )
            );
      }
      getNavigationArrow(e) {
        const { hasBgImage: t, category: a, section: o } = this.props;
        let n, l, i, s;
        return (
          e === _
            ? ((n = (global._ || guac.lodash).merge({}, re.arrow, {
                right: "-35px",
              })),
              (l = this.gotoPage(!0)),
              (i = "chevronRight"),
              (s = r.RIGHT_ARROW_RENDERED))
            : ((n = (global._ || guac.lodash).merge({}, re.arrow, {
                left: "-40px",
              })),
              (l = this.gotoPage(!1)),
              (i = "chevronLeft"),
              (s = r.LEFT_ARROW_RENDERED)),
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            {
              "data-aid": s,
              category: t ? "accent" : a,
              section: t ? "overlay" : o,
              onClick: l,
              style: n,
            },
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Icon,
              { icon: i }
            )
          )
        );
      }
      getPaginationControl() {
        const { pages: e } = this.state;
        return (
          e > 1 &&
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            { style: re.paginationContainer },
            (global._ || guac.lodash).range(e).map((t) => {
              const a = t + 1;
              return e >= a
                ? (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Block,
                    {
                      style: this.getPageDotStyles(a),
                      onClick: this.updateCurrentPage(a),
                    }
                  )
                : null;
            })
          )
        );
      }
      getConnectProviderHandler() {
        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        return () => {
          const {
              isReseller: t,
              env: a,
              accountId: o,
              websiteId: r,
            } = this.props,
            n = this.getProvider(),
            l = e ? x : P;
          window.location.href = l[n]
            .replace(
              "{rootDomain}",
              ((e, t) => (t ? I.reseller : I.godaddy)[e])(a, t)
            )
            .replace("{accountId}", o)
            .replace("{websiteId}", r)
            .replace("{home}", window.location.href);
        };
      }
      renderMessageInContainer(e, t, a, o) {
        if (!e) return null;
        const r = {
          container: {
            display: "flex",
            flexDirection: "column",
            textAlign: "center",
            justifyContent: "center",
          },
          messageBlock: {
            paddingHorizontal: a ? "xsmall" : "xxlarge",
            paddingVertical: a ? "large" : "xlarger",
            margin: "auto",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            backgroundColor: "section",
          },
          icon: { width: "45px", height: "45px", marginBottom: "medium" },
        };
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Container,
          { style: r.container },
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
            { category: "accent", section: "overlay", style: r.messageBlock },
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
              null,
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Icon,
                { icon: p[o], style: r.icon }
              ),
              e
            )
          )
        );
      }
      displayNoReviewsMessage() {
        const { section: e, staticContent: t, hasBgImage: a } = this.props,
          o = { "data-aid": r.REVIEWS_NO_DATA_RENDERED };
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component
            .PlaceholderMessage,
          {
            section: a ? "overlay" : "default" === e ? "alt" : "default",
            message: t.comingSoon,
            textProps: o,
          }
        );
      }
      displayMessages(e, t, a, o) {
        const { isMobile: r } = this.state,
          { hasBgImage: n } = this.props,
          l = (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            null,
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
              { style: { fontWeight: "bold" }, children: e, "data-aid": a }
            ),
            (global.React || guac.react).createElement(
              (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
              { style: { marginTop: "medium" }, children: t, "data-aid": o }
            )
          );
        return this.renderMessageInContainer(l, n, r, this.getProvider());
      }
      displayPendingMessage() {
        const { staticContent: e } = this.props;
        return this.displayMessages(
          e.txtPendingValidation,
          e.gmb3Days,
          r.PENDING_VALIDATION_HEADER,
          r.PENDING_VALIDATION_CONTENT
        );
      }
      displayWaitMessage() {
        const { staticContent: e } = this.props;
        return this.displayMessages(
          e.connectionSuccess,
          e.twentyFourHourLag,
          r.WAITING_FOR_DATA_HEADER,
          r.WAITING_FOR_DATA_CONTENT
        );
      }
      displayConnectOrUpgradeMessage() {
        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const {
            staticContent: t,
            renderMode: a,
            publishDate: o,
            publishAfterLastUpgrade: n,
          } = this.props,
          l = this.getProvider(),
          i = ee.concat(te).includes(l) && (!o || n),
          s = h[l],
          c = {
            renderMode: a,
            beforeContent: (global.React || guac.react).createElement(
              (global.React || guac.react).Fragment,
              null,
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Icon,
                {
                  icon: p[l],
                  style: {
                    width: "45px",
                    height: "45px",
                    marginBottom: "medium",
                  },
                }
              ),
              (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Text,
                {
                  typography: "none",
                  children: t[e ? "upgradeMessage" : "connectMsg"].replace(
                    "{provider}",
                    s
                  ),
                  "data-aid": e
                    ? r.UPGRADE_TIER_MSG
                    : r.REVIEWS_NOT_CONNECTED_MSG,
                }
              ),
              i &&
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  { style: { marginTop: "medium" } },
                  t.publishMessage.replace("{provider}", s)
                )
            ),
            button: {
              typography: "none",
              style: i
                ? { opacity: "0.6", pointerEvents: "none" }
                : { opacity: "1" },
              onClick: e
                ? this.getConnectProviderHandler(!0)
                : this.getConnectProviderHandler(),
              children: t[e ? "upgradeNow" : "connectBtnText"].replace(
                "{provider}",
                s
              ),
              "data-event": g[l],
              "data-aid": r.REVIEWS_CONNECT_BUTTON,
            },
          };
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component
            .ZeroStateOverlay,
          c
        );
      }
      renderReviews() {
        const { data: e, isMobile: t } = this.state,
          a = e.reviews && e.reviews.length > this.state.cardsPerPage;
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
          { style: re.container },
          (global.React || guac.react).createElement(
            (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Block,
            { style: re.cardsContainer },
            !t && a && this.getNavigationArrow(N),
            this.getCards(),
            !t && a && this.getNavigationArrow(_)
          ),
          !t && this.getPaginationControl()
        );
      }
      showWaitMessage() {
        const { state: e, providerState: t } = this.state,
          { renderMode: a, gmbShowPendingMessage: o, fbPageId: r } = this.props,
          c = this.getProvider();
        return (
          a ===
            (global.Core || guac["@wsb/guac-widget-core"]).constants.renderModes
              .EDIT &&
          e === R &&
          (c === i
            ? t === T && !o
            : c === n
            ? !!r
            : (c === l || c === s) && t === T)
        );
      }
      isProviderNotSetup(e) {
        const { providerState: t, planUpgradeRequired: a } = this.state;
        if (a) return !1;
        return ee.concat(te).includes(e)
          ? !(t === T)
          : e === n
          ? !this.props.fbPageId
          : e !== c;
      }
      providerHasReviews(e) {
        const { manualReviews: t } = this.props;
        return e === c ? t && t.length : this.state.state === v;
      }
      getContainerStyles(e) {
        const { renderMode: t } = this.props;
        let a = "50px";
        t !==
          (global.Core || guac["@wsb/guac-widget-core"]).constants.renderModes
            .EDIT && (a = e ? "unset" : "500px");
        return { display: "flex", flexDirection: "column", minHeight: a };
      }
      displayReviewBar(e, t) {
        const { staticContent: a, hasBgImage: n } = this.props,
          { isMobile: l, data: i, state: s } = this.state,
          c = (i && i.metadata && i.metadata.name) || "";
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Container,
          { style: e },
          (global.React || guac.react).createElement(
            U,
            o({}, this.props, {
              hasBgImage: n,
              overallRating: i.overallRating || 0,
              businessName: c,
              provider: t,
              staticContent: a,
              isMobile: l,
              pageLink: this.getPageLink(i, t),
              totalReviews: i.totalReviews || 0,
              negativeRecommendations: i.negativeRecommendations || 0,
              positiveRecommendations: i.positiveRecommendations || 0,
            })
          ),
          s === w
            ? (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                  .Loader,
                { "data-aid": r.REVIEWS_LOADER, style: { margin: "0 auto" } }
              )
            : this.renderReviews()
        );
      }
      render() {
        const { state: e, planUpgradeRequired: t } = this.state,
          {
            hasBgImage: a,
            gmbShowPendingMessage: o,
            renderMode: r,
            category: n,
            section: l,
          } = this.props,
          i = this.getProvider(),
          s = this.providerHasReviews(i),
          c = this.isProviderNotSetup(i),
          g =
            o &&
            !s &&
            r ===
              (global.Core || guac["@wsb/guac-widget-core"]).constants
                .renderModes.EDIT,
          p =
            e === f ||
            (r !==
              (global.Core || guac["@wsb/guac-widget-core"]).constants
                .renderModes.EDIT &&
              e === R),
          d = this.getContainerStyles(p);
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element.Container,
          {
            category: a ? "accent" : n,
            section: a ? "overlay" : l,
            style: d,
            group: "Group",
          },
          (global.React || guac.react).createElement(J, {
            onChange: this.handleMatchMedia,
          }),
          s && this.displayReviewBar(d, i),
          t && this.displayConnectOrUpgradeMessage(!0),
          this.showWaitMessage() && this.displayWaitMessage(),
          p && this.displayNoReviewsMessage(),
          !s && c && this.displayConnectOrUpgradeMessage(),
          g && this.displayPendingMessage()
        );
      }
    }
    a(ne, "propTypes", {
      viewDevice: (global.PropTypes || guac["prop-types"]).string.isRequired,
      renderMode: (global.PropTypes || guac["prop-types"]).string.isRequired,
      websiteId: (global.PropTypes || guac["prop-types"]).string.isRequired,
      accountId: (global.PropTypes || guac["prop-types"]).string.isRequired,
      isReseller: (global.PropTypes || guac["prop-types"]).bool.isRequired,
      env: (global.PropTypes || guac["prop-types"]).string.isRequired,
      staticContent: (global.PropTypes || guac["prop-types"]).object,
      hasBgImage: (global.PropTypes || guac["prop-types"]).bool,
      publishDate: (global.PropTypes || guac["prop-types"]).string,
      category: (global.PropTypes || guac["prop-types"]).string,
      section: (global.PropTypes || guac["prop-types"]).string,
      gmbShowPendingMessage: (global.PropTypes || guac["prop-types"]).bool,
      providerType: (global.PropTypes || guac["prop-types"]).string,
      fbPageId: (global.PropTypes || guac["prop-types"]).string,
      fontScale: (global.PropTypes || guac["prop-types"]).string,
      planType: (global.PropTypes || guac["prop-types"]).string,
      publishAfterLastUpgrade: (global.PropTypes || guac["prop-types"]).bool,
      sourceType: (global.PropTypes || guac["prop-types"]).string,
      manualReviews: (global.PropTypes || guac["prop-types"]).array,
      market: (global.PropTypes || guac["prop-types"]).string,
    }),
      (e.default = ne),
      Object.defineProperty(e, "__esModule", { value: !0 });
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-Component-b68d670c.js.map
