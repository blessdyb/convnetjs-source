define(
  "@widget/GALLERY/c/bs-renderLightbox-c8b9462b.js",
  [
    "exports",
    "@wsb/guac-widget-shared@^1/lib/components/Carousel",
    "~/c/bs-CustomArrows",
    "~/c/bs-dataAids",
  ],
  function (e, t, a, o) {
    "use strict";
    class r extends (global.React || guac.react).Component {
      static get propTypes() {
        return {
          prevSlide: (global.PropTypes || guac["prop-types"]).func.isRequired,
          nextSlide: (global.PropTypes || guac["prop-types"]).func.isRequired,
        };
      }
      constructor() {
        super(...arguments), (this.handleKey = this.handleKey.bind(this));
      }
      handleKey(e) {
        let { keyCode: t } = e;
        const { prevSlide: a, nextSlide: o } = this.props;
        37 === t ? a() : 39 === t && o();
      }
      componentDidMount() {
        document.addEventListener("keydown", this.handleKey, !1);
      }
      componentWillUnmount() {
        document.removeEventListener("keydown", this.handleKey, !1);
      }
      render() {
        return null;
      }
    }
    const { Z_INDEX_FULL_SCREEN_OVERLAY: n } = (
        global.Core || guac["@wsb/guac-widget-core"]
      ).constants.layers,
      i =
        "undefined" != typeof navigator &&
        11 ===
          parseInt(
            (/trident\/.*; rv:(\d+)/i.exec(navigator.userAgent) || [])[1],
            10
          );
    class l extends (global.React || guac.react).Component {
      static get propTypes() {
        return {
          images: (global.PropTypes || guac["prop-types"]).arrayOf(
            (global.PropTypes || guac["prop-types"]).shape({
              image: (global.PropTypes || guac["prop-types"]).string.isRequired,
              caption: (global.PropTypes || guac["prop-types"]).string,
            })
          ).isRequired,
          selectedIndex: (global.PropTypes || guac["prop-types"]).number
            .isRequired,
          visible: (global.PropTypes || guac["prop-types"]).bool.isRequired,
          onRequestClose: (global.PropTypes || guac["prop-types"]).func
            .isRequired,
          size: (global.PropTypes || guac["prop-types"]).string,
          renderMode: (global.PropTypes || guac["prop-types"]).string,
        };
      }
      constructor(e) {
        super(...arguments),
          (this.afterChange = this.afterChange.bind(this)),
          (this.beforeChange = this.beforeChange.bind(this)),
          (this.state = { currentIndex: e.selectedIndex });
      }
      beforeChange(e) {
        this.setState({ currentIndex: e });
      }
      afterChange(e) {
        this.setState({ currentIndex: e });
      }
      render() {
        const {
            images: e,
            visible: l,
            onRequestClose: c,
            size: s,
            renderMode: g,
          } = this.props,
          { currentIndex: d } = this.state,
          p = "xs" === s || "sm" === s,
          u = "md" === s,
          b = {
            maxWidth: p ? "90vw" : "70vw",
            maxHeight: p ? "60vh" : "70vh",
            objectFit: "contain",
          },
          h = {
            maxWidth: p ? "90%" : "750px",
            padding: 0,
            textAlign: "center",
            marginVertical: "medium",
            marginHorizontal: "auto",
            color: "white",
            height: "auto",
            maxHeight: p ? "30vh" : "20vh",
            overflowY: "auto",
            WebkitOverflowScrolling: "touch",
          },
          m = {
            width: p ? "90%" : "76%",
            textAlign: "right",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            top: p ? "medium" : "xlarger",
            left: "50%",
            transform: "translateX(-50%)",
            color: "white",
            position: "absolute",
            zIndex: 2,
          },
          y = {
            position: "fixed",
            zIndex: n,
            background: "rgba(0, 0, 0, 0.9)",
            padding: "0",
            border: "0",
            overflow: "hidden",
            borderRadius: "0",
            opacity: "1",
          },
          w = { container: { zIndex: 1 } },
          C = p
            ? []
            : [
                {
                  component: a.C,
                  props: {
                    visible: e.length > 1,
                    overrideArrowStyle: {
                      borderRadius: "50%",
                      marginHorizontal: u ? "5%" : "10%",
                      width: "40px",
                      height: "40px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      ...("PREVIEW" === g && {
                        top: "40%",
                        "@xs-only": { top: "25%" },
                      }),
                    },
                  },
                  position: "bottom",
                },
                { component: r },
              ],
          x = l
            ? (global.React || guac.react).createElement(
                (global.Core || guac["@wsb/guac-widget-core"]).UX2.Group
                  .Carousel,
                {
                  onTouchMove: (e) => {
                    e.preventDefault();
                  },
                },
                (global.React || guac.react).createElement(
                  (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                    .Block,
                  { category: "accent", section: "overlay", style: m },
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Text.Major,
                    { children: `${d + 1} / ${e.length}`, featured: !0 }
                  ),
                  (global.React || guac.react).createElement(
                    (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                      .Icon,
                    {
                      icon: "close",
                      "data-aid": o.d.LIGHTBOX_CLOSE,
                      style: {
                        cursor: "pointer",
                        color: "section",
                        marginRight: "-10px",
                      },
                      onClick: c,
                    }
                  )
                ),
                (global.React || guac.react).createElement(
                  t.default,
                  {
                    initialSlide: d,
                    dots: !1,
                    arrows: !1,
                    cellPadding: 0,
                    infinite: !0,
                    draggable: p,
                    autoplay: !1,
                    clickToNavigate: !1,
                    afterChange: this.afterChange,
                    beforeChange: this.beforeChange,
                    slideHeight: "100vh",
                    slideWidth: "100vw",
                    controls: C,
                    transition: p ? "slide" : "fade",
                    transitionDuration: p ? 500 : 250,
                    style: w,
                  },
                  e.map((e, t) => {
                    let { image: a, caption: r } = e;
                    const n = {
                        position: "absolute",
                        top: "-50px",
                        left: "-50px",
                        right: "-50px",
                        bottom: "-50px",
                        backgroundImage: `url(${a.image})`,
                        backgroundSize: "cover",
                        filter: "blur(40px) brightness(50%)",
                      },
                      l =
                        i || p
                          ? null
                          : (global.React || guac.react).createElement(
                              (global.Core || guac["@wsb/guac-widget-core"]).UX2
                                .Element.Block,
                              {
                                "data-aid": o.d.CAROUSEL_BLUR_BACKGROUND,
                                onClick: c,
                                style: n,
                              }
                            );
                    return (global.React || guac.react).createElement(
                      (global.Core || guac["@wsb/guac-widget-core"]).UX2.Element
                        .Block,
                      {
                        category: "accent",
                        section: "overlay",
                        "data-aid": o.d.CAROUSEL_BACKGROUND,
                        onClick: c,
                        key: t,
                        style: {
                          width: "100%",
                          height: "100%",
                          position: "relative",
                        },
                      },
                      l,
                      (global.React || guac.react).createElement(
                        (global.Core || guac["@wsb/guac-widget-core"]).UX2
                          .Element.Block,
                        {
                          "data-aid": o.d.CAROUSEL_CONTENT,
                          onClick: (e) => {
                            e.stopPropagation();
                          },
                          style: {
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            textAlign: "center",
                            ...("PREVIEW" === g && {
                              top: "40%",
                              "@xs-only": { top: "25%" },
                            }),
                          },
                        },
                        (global.React || guac.react).createElement(
                          (global.Core || guac["@wsb/guac-widget-core"]).UX2
                            .Element.Image,
                          {
                            style: b,
                            imageData: (global._ || guac.lodash).omit(a, [
                              "top",
                              "left",
                              "width",
                              "height",
                              "rotation",
                            ]),
                          }
                        ),
                        r &&
                          (global.React || guac.react).createElement(
                            (global.Core || guac["@wsb/guac-widget-core"]).UX2
                              .Element.Text,
                            {
                              "data-aid": o.d.CAROUSEL_IMAGE_CAPTION,
                              style: h,
                              children: r,
                              richtext: !0,
                              featured: !0,
                            }
                          )
                      )
                    );
                  })
                )
              )
            : null;
        return (global.React || guac.react).createElement(
          (global.Core || guac["@wsb/guac-widget-core"]).UX2.Component.Modal
            .Overlay,
          { style: y },
          x
        );
      }
    }
    e.r = function () {
      const { galleryImages: e, size: t, renderMode: a } = this.props,
        { showLightbox: r, selectedIndex: n } = this.state,
        i = [].concat(...e);
      return i.length && r
        ? (global.React || guac.react).createElement(l, {
            images: i.map((e) => ({ image: e.image, caption: e.caption })),
            visible: !0,
            selectedIndex: n,
            onRequestClose: this.hideLightbox,
            size: t,
            "data-aid": o.d.LIGHTBOX_MODAL,
            renderMode: a,
          })
        : null;
    };
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-renderLightbox-c8b9462b.js.map
