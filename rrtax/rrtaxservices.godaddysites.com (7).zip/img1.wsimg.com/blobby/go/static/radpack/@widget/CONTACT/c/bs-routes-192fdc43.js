define("@widget/CONTACT/c/bs-routes-192fdc43.js", ["exports"], function (e) {
  "use strict";
  (e.F = {
    SECTION_TITLE: "sectionTitle",
    INFO_TITLE: "infoTitle",
    INFO: "info",
    BUSINESS_NAME: "businessName",
    ADDRESS: "address",
    PHONE: "phone",
    FORM: "formFields",
    FORM_TITLE: "formTitle",
    HOURS: "structuredHours",
    HOURS_TITLE: "hoursTitle",
    HOURS_CUSTOM_MESSAGE: "hoursCustomMessage",
    WHATS_APP: "whatsApp",
    IMAGE: "image",
  }),
    (e.H = "/hours"),
    (e.a = "/form");
}),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-routes-192fdc43.js.map
