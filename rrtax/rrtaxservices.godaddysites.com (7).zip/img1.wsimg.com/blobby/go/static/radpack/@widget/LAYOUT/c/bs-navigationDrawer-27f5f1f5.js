define(
  "@widget/LAYOUT/c/bs-navigationDrawer-27f5f1f5.js",
  ["exports"],
  function (i) {
    "use strict";
    i.N = "-249vw";
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-navigationDrawer-27f5f1f5.js.map
