import { XSMALL, SMALL, MEDIUM, LARGE, XLARGE } from "../breakpoints";

export { XSMALL, SMALL, MEDIUM, LARGE, XLARGE };
export default [XSMALL, SMALL, MEDIUM, LARGE, XLARGE];
