export const XSMALL = "xs";
export const SMALL = "sm";
export const MEDIUM = "md";
export const LARGE = "lg";
export const XLARGE = "xl";

export default [XSMALL, SMALL, MEDIUM, LARGE];
