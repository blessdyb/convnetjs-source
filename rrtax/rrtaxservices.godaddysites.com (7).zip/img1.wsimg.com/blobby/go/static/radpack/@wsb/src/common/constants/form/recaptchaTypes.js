import keyMirror from "keymirror";

export default keyMirror({
  V3: null,
});
