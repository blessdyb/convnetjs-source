export const NAV_DRAWER_OFFSET = "-249vw";
