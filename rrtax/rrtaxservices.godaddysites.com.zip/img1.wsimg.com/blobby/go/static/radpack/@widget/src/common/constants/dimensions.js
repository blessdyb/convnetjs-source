export const thumbImageDimensions = {
  height: 70,
  width: 100,
};
export const smallthumbImageDimensions = {
  height: 68,
  width: 95,
};
