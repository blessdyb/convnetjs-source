export const TABLET = "tablet";
export const MOBILE = "mobile";
