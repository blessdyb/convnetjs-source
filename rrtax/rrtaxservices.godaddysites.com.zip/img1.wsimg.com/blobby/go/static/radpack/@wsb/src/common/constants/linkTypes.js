export const PRODUCTS = "products";
export const EXTERNAL = "external";
export const INTERNAL = "internal";
export const EXTERNAL_LINK_LEGACY = "EXTERNAL";
export const EMPTY_LINK = "#";
export const PHONE = "phone";
export const EMAIL = "email";
