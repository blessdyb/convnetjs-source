define(
  "@wsb/guac-widget-shared/c/_react-dom_commonjs-external-61540793.js",
  ["exports"],
  function (e) {
    "use strict";
    const o = global.ReactDOM || guac["react-dom"];
    e._ = o;
  }
),
  "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=_react-dom_commonjs-external-61540793.js.map
