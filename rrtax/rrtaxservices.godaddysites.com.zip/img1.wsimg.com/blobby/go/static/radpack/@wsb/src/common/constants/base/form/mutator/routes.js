export const FORM_PIVOT = "/form";
export const FORM_FIELD = "/form/$";
