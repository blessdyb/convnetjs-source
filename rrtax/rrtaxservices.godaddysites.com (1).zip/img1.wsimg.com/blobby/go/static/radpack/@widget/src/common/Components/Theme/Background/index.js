import { Background, BackgroundHalf } from "./Background";

Background.Half = BackgroundHalf;

export { Background };
