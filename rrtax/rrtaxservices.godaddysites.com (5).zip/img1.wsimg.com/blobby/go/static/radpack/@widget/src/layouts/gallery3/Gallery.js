import React, { Component } from "react";
import PropTypes from "prop-types";
import { UX2, utils } from "@wsb/guac-widget-core";
import Carousel from "@wsb/guac-widget-shared/lib/components/Carousel";
import CustomArrows from "../../common/components/CustomArrows";
import ThumbnailNavList from "../../common/components/ThumbnailNavList";
import FakeThumbNav from "../../common/components/FakeThumbNav";
import {
  dataAids,
  getGalleryDataAid,
  getGalleryDataRouteProps,
} from "../../common/constants/dataAids";
import getImageUrl from "../../common/util";
import wrapWithDeviceDetection from "../../common/wrapWithDeviceDetection";
import {
  modifyKeyDownEventHandler,
  handleDirectionalKeys,
} from "../../common/directionalKeyHandlers";
import { smallthumbImageDimensions as thumbImageDimensions } from "../../common/constants/dimensions";
import { debounce } from "lodash";

const ASPECT_RATIO = 56.25;

export default wrapWithDeviceDetection(
  class Gallery3 extends Component {
    constructor(props) {
      super(props);

      this.state = {
        arrows: false,
        currentSlide: 0,
        nextSlideIncremental: 0,
        mouseOnCarousel: false,
      };
      this.handleMouseMove = this.handleMouseMove.bind(this);
      this.handleMouseLeave = this.handleMouseLeave.bind(this);
      this.handleMouseEnter = this.handleMouseEnter.bind(this);
      this.nextSlideDebounced = debounce(
        (input) =>
          handleDirectionalKeys({ keyCode: input.keyCode, context: this }),
        200
      );
      this._loadedImages = new Set();
    }

    static getDerivedStateFromProps(nextProps, prevState) {
      const { images = [] } = nextProps;
      const { currentSlide } = prevState;
      return currentSlide >= images.length ? { currentSlide: 0 } : null;
    }

    handleMouseLeave() {
      this.setState({ mouseOnCarousel: false, arrows: false });
    }

    handleMouseEnter() {
      this.setState({ mouseOnCarousel: true });
      this.handleMouseMove();
    }

    handleMouseMove() {
      if (!this.state.arrows) {
        this.setState({ arrows: true });
      }
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.setState({ arrows: false });
      }, 2000);
    }

    handleSlideChange(newIndex) {
      this.setState({ currentSlide: newIndex });
    }

    static get propTypes() {
      return {
        autoplay: PropTypes.bool,
        category: PropTypes.string,
        className: PropTypes.string,
        device: PropTypes.string,
        images: PropTypes.array,
        renderAsThumbnail: PropTypes.bool,
        section: PropTypes.string,
        showthumbnailsThirdLayout: PropTypes.bool,
        size: PropTypes.string,
        currentImageSelected: PropTypes.string,
        autoplayDelay: PropTypes.string,
        showSlideNum: PropTypes.bool,
        fullBleed: PropTypes.bool,
        transitionType: PropTypes.string,
        showArrows: PropTypes.bool,
      };
    }

    static get defaultProps() {
      return {
        category: "neutral",
        images: [],
      };
    }

    render() {
      const {
        device,
        showthumbnailsThirdLayout,
        fullBleed,
        images,
        showArrows,
        transitionType,
      } = this.props;

      const { nextSlideIncremental, arrows } = this.state;

      const Grid = UX2.Component.Grid;

      const imageComponents = this.renderImages();
      const isMobile = device === "mobile";
      const forceArrows = transitionType === "fade" && isMobile;
      const controls =
        images.length > 1 && (showArrows || forceArrows)
          ? [
              {
                component: CustomArrows,
                props: {
                  visible: arrows || forceArrows,
                  triggerNextSlide: nextSlideIncremental,
                },
                position: "bottom",
              },
            ]
          : [];
      if (showthumbnailsThirdLayout && images.length > 1) {
        const { width, height } = thumbImageDimensions;
        const thumbArray = images.map(({ imageData }) => {
          return {
            url: getImageUrl(
              utils.generateBackgroundUrl(imageData),
              width,
              height,
              "background"
            ),
            caption: imageData.caption,
            alt: imageData.alt,
          };
        });
        const overrideStyle = {
          position: "absolute",
          width: "100%",
          left: "50%",
          transform: "translateX(-50%)",
        };
        if (!isMobile) {
          controls.push({
            component: ThumbnailNavList,
            props: {
              images: thumbArray,
              overrideStyle,
              thumbWidth: 95,
              thumbHeight: height,
              renderContainer: fullBleed,
            },
            position: "bottom",
          });
        }
      }
      const carouselParams =
        isMobile && !forceArrows
          ? { imageComponents }
          : { imageComponents, controls };
      const carouselInner = imageComponents.length > 0 && (
        <UX2.Group.Carousel
          onMouseMove={this.handleMouseMove}
          onMouseEnter={this.handleMouseEnter}
          onMouseLeave={this.handleMouseLeave}
          data-route=""
          children={this.renderCarouselComponents(carouselParams, isMobile)}
        />
      );
      const carouselEl =
        carouselInner &&
        (fullBleed ? (
          carouselInner
        ) : (
          <UX2.Element.Container>
            <Grid size={1} bottom={false}>
              {carouselInner}
            </Grid>
          </UX2.Element.Container>
        ));

      return carouselEl;
    }

    componentDidUpdate(prevProps) {
      const { currentImageSelected } = this.props;
      if (
        currentImageSelected !== prevProps.currentImageSelected &&
        currentImageSelected > -1
      ) {
        this.setState({ currentSlide: parseInt(currentImageSelected, 10) });
      }
    }

    componentWillUnmount() {
      modifyKeyDownEventHandler(this.nextSlideDebounced);
    }

    renderCaptionOverlay(caption) {
      const { images, showSlideNum, fullBleed } = this.props;
      const { currentSlide } = this.state;
      const prependZero = images.length > 10 && currentSlide + 1 < 10 ? 0 : "";
      const slidePosition = `${prependZero}${currentSlide + 1}/${
        images.length
      }`;
      const renderSlideNum = showSlideNum && images.length > 1;
      const styles = {
        overlayStyle: {
          zIndex: 1,
        },
        fullBleedBlockStyle: {
          width: "100%",
          paddingHorizontal: "0px !important",
        },
        containerStyle: {
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
        },
        captionStyle: {
          flexGrow: "1 !important",
          textAlign: renderSlideNum ? "left" : "center",
        },
        slideNumStyle: {
          flexGrow: 0,
        },
      };

      if (!caption && !renderSlideNum) {
        return null;
      }

      const overlayInner = (
        <React.Fragment>
          {caption && (
            <UX2.Element.Text
              data-aid={dataAids.GALLERY_CAPTION_RENDERED}
              children={caption}
              style={styles.captionStyle}
              richtext
            />
          )}
          {renderSlideNum && (
            <UX2.Element.Text
              data-aid={dataAids.GALLERY_SLIDE_POSITION}
              children={slidePosition}
              style={styles.slideNumStyle}
            />
          )}
        </React.Fragment>
      );
      return fullBleed ? (
        <UX2.Element.FigCaption.Overlay style={styles.overlayStyle}>
          <UX2.Element.Block style={styles.fullBleedBlockStyle}>
            <UX2.Element.Container style={styles.containerStyle}>
              {overlayInner}
            </UX2.Element.Container>
          </UX2.Element.Block>
        </UX2.Element.FigCaption.Overlay>
      ) : (
        <UX2.Element.FigCaption.Overlay style={styles.overlayStyle}>
          {overlayInner}
        </UX2.Element.FigCaption.Overlay>
      );
    }

    renderCarouselComponents(renderOptions, isMobile) {
      const { imageComponents, controls } = renderOptions;
      const {
        autoplay,
        autoplayDelay,
        renderAsThumbnail,
        images,
        showthumbnailsThirdLayout,
        device,
        size,
        currentImageSelected,
        transitionType,
        fullBleed,
      } = this.props;
      const { currentSlide } = this.state;
      const resolvedIndex =
        currentImageSelected > -1
          ? parseInt(currentImageSelected, 10)
          : currentSlide;
      const initialSlideProp = { initialSlide: parseInt(resolvedIndex, 10) };
      const caption = images[currentSlide].caption || "";
      const renderFakeThumbnail =
        renderAsThumbnail && (device === "mobile" || size === "xs");
      const autoplaySpeed = (parseFloat(autoplayDelay) || 3.5) * 1000;
      const captionOverlay = this.renderCaptionOverlay(caption);
      const imgHeight = ASPECT_RATIO;
      const slideStyle = {
        paddingBottom: `${imgHeight}%`,
      };
      if (transitionType !== "fade") {
        slideStyle.opacity = 1;
        slideStyle.position = "relative";
      }
      const carousel = renderAsThumbnail ? (
        imageComponents[0]
      ) : (
        <Carousel
          key={currentImageSelected}
          slideWidth="100%"
          arrows={false}
          autoplay={autoplay}
          autoplaySpeed={autoplaySpeed}
          dots={false}
          draggable={images.length > 1}
          afterChange={this.handleSlideChange.bind(this)}
          controls={controls || []}
          children={imageComponents}
          transition={transitionType}
          pauseOnHover={!fullBleed}
          style={{
            slide: slideStyle,
            viewport: {
              paddingBottom: transitionType === "fade" ? `${imgHeight}%` : 0,
            },
            track: { lineHeight: 0 },
          }}
          {...initialSlideProp}
        />
      );
      let thumbStyle;
      if (renderAsThumbnail) {
        thumbStyle = {
          height: 650,
          width: 900,
          marginLeft: "auto",
          marginRight: "auto",
        };
      }
      let marginBottom;
      if (showthumbnailsThirdLayout && (!isMobile || renderAsThumbnail)) {
        marginBottom = "xxlarger";
      }
      return (
        <UX2.Element.Block
          style={{ ...thumbStyle, marginBottom, position: "relative" }}
        >
          {carousel}
          {captionOverlay}
          {renderFakeThumbnail && showthumbnailsThirdLayout && (
            <FakeThumbNav
              images={images}
              thumbImageDimensions={thumbImageDimensions}
              imageType="background"
              baseStyle={{
                position: "absolute",
                bottom: -80,
                overflow: "hidden",
                width: "100%",
              }}
            />
          )}
        </UX2.Element.Block>
      );
    }

    renderImages() {
      const { images } = this.props;
      const { currentSlide } = this.state;
      const renderedIndices = new Set([
        currentSlide - 1 < 0 ? images.length - 1 : currentSlide - 1,
        currentSlide,
        currentSlide + 1 === images.length ? 0 : currentSlide + 1,
      ]);
      const imageComponents = images.map((img, index) => {
        const { imageData = {}, caption, position = "center" } = img;
        const { src } = imageData;
        const shouldRender = Boolean(
          renderedIndices.has(index) || this._loadedImages.has(src)
        );
        if (shouldRender) {
          this._loadedImages.add(src);

          return (
            <UX2.Component.Background
              key={index}
              imageData={imageData}
              data-route=""
              data-aid={getGalleryDataAid(index)}
              alt={caption || ""}
              style={{
                top: 0,
                left: 0,
                position: "absolute !important",
                overflow: "hidden",
                marginBottom: 0,
                height: "100%",
                width: "100%",
                backgroundPosition: position,
              }}
              onMouseEnter={modifyKeyDownEventHandler.bind(
                this,
                this.nextSlideDebounced,
                true
              )}
              onMouseLeave={modifyKeyDownEventHandler.bind(
                this,
                this.nextSlideDebounced
              )}
              {...getGalleryDataRouteProps(index, {
                isImage: true,
                useImageField: false,
              })}
            />
          );
        }

        return <div key={index} />;
      });
      return imageComponents;
    }
  }
);
