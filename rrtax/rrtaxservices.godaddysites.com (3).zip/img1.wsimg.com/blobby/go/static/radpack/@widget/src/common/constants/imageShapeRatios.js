export const imageShapeRatios = {
  vertical: "133%",
  square: "100%",
  horizontal: "75%",
};
