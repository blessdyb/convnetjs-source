export const DESKTOP_NAV = "DESKTOP_NAV";
export const DESKTOP_NAV_COVER = "DESKTOP_NAV_COVER";
export const NAV_DRAWER = "NAV_DRAWER";
export const SIDEBAR = "SIDEBAR";
export const MOBILE_NAV = "MOBILE_NAV";
