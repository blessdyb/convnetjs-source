import Grid from "./Grid";
import Cell from "./Cell";

Grid.Cell = Cell;

export { Grid };
